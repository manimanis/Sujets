<html>


<body bgcolor="#FFFF66">
<?
mysql_pconnect("localhost","root","");
mysql_select_db("bd123456");
echo "<font size='7' color='red'><center>Le cumul des votes</center></font><br><br><br>";
echo "<table width=80% align='center' border='1'><tr><td><b>Nom</b></td><td><b>Pr�nom</b></td><td><b>Cumul des votes</b> </td></tr>";
$requete = "select * from vote where numc=8000";
$r=mysql_query($requete);

    $n=mysql_num_rows($r);
   echo "<tr><td><b>Abbassi</b><td> <b>Sihem</b></td><td><b>".$n."</b></td></tr>";
   
 $requete = "select * from vote where numc=8001";
$r=mysql_query($requete);

    $n=mysql_num_rows($r);
   echo "<tr><td><b>Ben Abdallah</b><td> <b>Kacem</b></td><td><b>".$n."</b></td></tr>";
  
 $requete = "select * from vote where numc=9000";
$r=mysql_query($requete);

    $n=mysql_num_rows($r);
   echo "<tr><td><b>Dridi</b><td> <b>Brahim</b></td><td><b>".$n."</b></td></tr>";

 $requete = "select * from vote where numc=9001";
$r=mysql_query($requete);

    $n=mysql_num_rows($r);
   echo "<tr><td><b>Troudi</b><td> <b>Meryem</b></td><td><b>".$n."</b></td></tr>";
echo "</table>";

 
?>

</body>

</html>