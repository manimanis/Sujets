<html>

<head>
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Nouvelle page 1</title>
</head>

<body bgcolor="#FFFF66">
<?
mysql_pconnect("localhost","root","");
mysql_select_db("bd123456");
$a=$_POST['T1'];
$b=$_POST['T2'];
$c=$_POST['T3'];
$d=$_POST['R1'];
$e=$_POST['D1'];

$requete = "select * from eleve where num='$a'";
$r=mysql_query($requete);
if(mysql_num_rows($r)!=0){
   echo "<font size='6' color='red'><center>Eleve d�j� inscrit!!!</center></font>";
   }
   else
   {
      $requete = "insert into eleve values('$a','$b','$c','$d','$e','N')";
        $r=mysql_query($requete);
    if($r==NULL){
   echo "<font size='6' color='red'><center>La requ�te a echou�e!!</center></font>";
   }
   else
   {
    echo "<font size='6' color='red'><center>Confirmation de l'inscription!!</center></font>";


   }   
}
?>

</body>

</html>