<html>


<body bgcolor="#FFFF66">
<?
mysql_pconnect("localhost","root","");
mysql_select_db("bd123456");
$a=$_POST['T1'];

$b=$_POST['R1'];


$requete = "select * from eleve where num='$a'";
$r=mysql_query($requete);
if(mysql_num_rows($r)==0){
   echo "<font size='6' color='red'><center>Vous n'�tes pas inscrit!!! </center></font>";
   }
   else
   {$requete = "select * from vote where nume='$a'";
     $r=mysql_query($requete);

 if(mysql_num_rows($r)!=0){
   echo "<font size='6' color='red'><center>Vous avez d�j� vot� </center></font>";
   }
   else{


       echo "<font size='6' color='red'><center>Merci pour votre vote!!!</center></font>";
      $requete = "insert into vote values('$a','$b')";
        $r=mysql_query($requete);
    if($r==NULL){
   echo "<font size='6' color='red'><center>La requ�te a echou�e!!</center></font>";
   }
   else
   {
    echo "<font size='6' color='red'><center>Reussite de l'op�ration de vote!!</center></font>";


   }   
}
}
?>
</body>

</html>