<html>

<head>

</head>

<body bgcolor="#FFFF66">
<?php
mysql_pconnect("localhost","root","");
mysql_select_db("bd654321");
$a=$_POST['T1'];
$b=$_POST['T2'];

$requete="select * from reclamation where telclt='$a'";
$r=mysql_query($requete);
if(mysql_num_rows($r)==0)
   echo "<font size='5' color='red'><center>Aucune r�clamation non trait� pour ce client</center></font>"; 
else
    {
    while ($tab=mysql_fetch_array($r)){
                 $etat=$tab['etat'];
                 $numrec=$tab['numrec'];
                  if($etat=='N'){
                      $requete="update reclamation set etat='O',daterep='$b' where numrec='$numrec' ";
						$req=mysql_query($requete);
						if($req==NULL)
   					echo "<font size='5' color='red'><center>Mise � jour echou�e</center></font>"; 
					else
					 echo "<font size='5' color='red'><center>Mise � jour effectu�e avec succ�s</center></font>"; 
                        }
                  
                  
                 }
    }
?>

</body>

</html>