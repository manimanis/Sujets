<html>

<head>

</head>

<body bgcolor="#FFFF66">
<html>



<body bgcolor="#FFFF66">
<?php
mysql_pconnect("localhost","root","");
mysql_select_db("bd654321");
$a=$_POST['T1'];
$b=$_POST['D1'];
$c=$_POST['S1'];
$requete="select * from client where telclt='$a'";
$r=mysql_query($requete);
if(mysql_num_rows($r)==0)
{
   echo "<font size='5' color='red'><center>Le client n'est pas enregistr� dans la base de donn�es</center></font>";
   }
   else
   { 
   $requete="select * from reclamation where telclt='$a'";
    $r=mysql_query($requete);
     if(mysql_num_rows($r)!=0){
       
       while ($tab=mysql_fetch_array($r)){
           $etat=$tab['etat'];
           if ($etat=='N')$ok=false;
        } 
        if ($ok==false)
      echo "<font size='5' color='red'><center>Le client admet une r�clamation non encore trait�e</center></font>"; 
          }
          else
          {   $requete="select * from categorie where libelle='$b'";
              $r=mysql_query($requete); 
                  while ($tab=mysql_fetch_array($r)){
                 $idcat=$tab['idcat'];
                 } 

              $d=date("Y-m-d H:i:s");
              $requete="insert into reclamation values ('','$c','N','$d','','$a','$idcat')";
              $r=mysql_query($requete);
               if($r==NULL){
               echo "<font size='5' color='red'><center>Ajout de client a echou�</center></font>";
               }else{
                   echo "<font size='5' color='red'><center>Ajout effectu�e avec succ�s</center></font>";
                   }
             }
       
  
  }    

?>
</body>

</html>
</body>

</html>