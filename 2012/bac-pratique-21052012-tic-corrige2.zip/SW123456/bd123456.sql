-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le : Sam 26 Mai 2012 à 08:25
-- Version du serveur: 5.5.20
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bd123456`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

CREATE TABLE IF NOT EXISTS `commentaire` (
  `numcom` int(11) NOT NULL AUTO_INCREMENT,
  `contenu` varchar(150) NOT NULL,
  `datecom` datetime NOT NULL,
  `pseudo` varchar(10) NOT NULL,
  `numsujet` int(11) NOT NULL,
  PRIMARY KEY (`numcom`)
) AUTO_INCREMENT=5 ;

--
-- Contenu de la table `commentaire`
--

INSERT INTO `commentaire` (`numcom`, `contenu`, `datecom`, `pseudo`, `numsujet`) VALUES
(2, '', '2012-05-26 08:13:25', 'bahmed', 2),
(3, 'Un commentaire sur la récursivité', '2012-05-26 08:15:53', 'bahmed', 2);

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

CREATE TABLE IF NOT EXISTS `membre` (
  `pseudo` varchar(10) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  PRIMARY KEY (`pseudo`)
) ;

--
-- Contenu de la table `membre`
--

INSERT INTO `membre` (`pseudo`, `nom`, `prenom`, `email`) VALUES
('Alia123', 'Sahbani', 'Alia', 'Sahbani.Alia@edunet.tn'),
('Bahmed', 'Bahri', 'Imed', 'bahri.Imed@gmail.com'),
('Besgabt', 'Gabtni', 'Besma', 'Besma.gabtni@gmail.com'),
('Hamrounif', 'Hamrouni', 'Fethi', 'Hamrouni@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `sujet`
--

CREATE TABLE IF NOT EXISTS `sujet` (
  `numsujet` int(11) NOT NULL,
  `theme` varchar(40) NOT NULL,
  `datesujet` date NOT NULL,
  PRIMARY KEY (`numsujet`)
) ;

--
-- Contenu de la table `sujet`
--

INSERT INTO `sujet` (`numsujet`, `theme`, `datesujet`) VALUES
(1, 'Les enregistrements et les fichiers', '2011-10-05'),
(2, 'La récursivité', '2011-11-11'),
(3, 'Les algorithmes de tri', '2012-01-15'),
(4, 'Les algorithmes arithmétiques', '2012-03-02');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
