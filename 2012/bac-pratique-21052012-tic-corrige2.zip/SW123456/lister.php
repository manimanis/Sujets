<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256" x-undefined>
<title>Nouvelle page 1</title>
</head>

<body style="font-family: Garamond; font-size: 12pt">
<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("bd123456");

$res = mysql_query("SELECT COUNT(*) FROM Membre WHERE pseudo = '".$_POST["pseudo"]."'");
$row = mysql_fetch_array($res);

if ($row[0] == 0) {
  echo '<p align="center"><font color="red">Pseudo Incorrect.</font></p>';
  die();
}

$res = mysql_query("SELECT * 
                    FROM Commentaire 
                    WHERE pseudo = '".$_POST["pseudo"]."' 
                      AND numsujet = '".$_POST["num_sujet"]."' ORDER BY datecom DESC");

if (mysql_num_rows($res) == 0) {
  echo '<p align="center"><font color="red">Vous n\'avez pas comment� le sujet s�lectionn�</font></p>';
  die();
}

echo "<table>\n";
while ($row = mysql_fetch_array($res)) {
  echo "<tr>\n";
  echo "<th>Date</th>\n";
  echo "</tr>\n";
  echo "<tr>\n";
  echo "<td>".$row["datecom"]."</td>\n";
  echo "</tr>\n";
  echo "<tr>\n";
  echo "<th>Contenu</th>\n";
  echo "</tr>\n";
  echo "<tr>\n";
  echo "<td>".$row["contenu"]."</td>\n";  
  echo "</tr>\n";
}
echo "</table>\n";
?>

</body>

</html>
