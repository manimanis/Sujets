<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256" x-undefined>
<title>Nouvelle page 1</title>
</head>

<body style="font-family: Garamond; font-size: 12pt">
<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("bd123456");

$res = mysql_query("SELECT COUNT(*) FROM Membre WHERE pseudo = '".$_POST["pseudo"]."'");
$row = mysql_fetch_array($res);

if ($row[0] == 0) {
  echo '<p align="center"><font color="red">Pseudo Incorrect.</font></p>';
  die();
}

$res = mysql_query("SELECT COUNT(*) 
                    FROM Commentaire 
                    WHERE pseudo = '".$_POST["pseudo"]."' 
                      AND numsujet = '".$_POST["num_sujet"]."'");
$row = mysql_fetch_array($res);

if ($row[0] == 0) {
  echo '<p align="center"><font color="red">Vous n\'avez pas comment� le sujet s�lectionn�</font></p>';
  die();
}

mysql_query("DELETE FROM commentaire 
            WHERE pseudo = '".$_POST["pseudo"]."' 
              AND numsujet = '".$_POST["num_sujet"]."'");
if (mysql_affected_rows() == -1) {
  echo '<p align="center"><font color="red">La suppression des donn�es a �chou�.</font></p>';
} else {
  echo '<p align="center"><font color="green">Donn�es suprim�es avec succ�s.</font></p>';  
}
?>

</body>

</html>
