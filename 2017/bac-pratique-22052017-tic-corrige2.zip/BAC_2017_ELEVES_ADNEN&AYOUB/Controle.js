function alpha (ch)
{
	var a = "azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN���"
	for (var i = 0 ; i <= ch.length ; i++)
	{
		if (a.indexOf(ch.charAt(i)) == -1)
		{
			return false;
		}
	}
	return true;
}
function numerique (ch)
{
	var n = "0123456789";
	for (var i = 0 ; i <= ch.length ; i++)
	{
		if (n.indexOf(ch.charAt(i)) == -1)
		{
			return false;
		}
	}
	return true;
}
function verif ()
{
	var cin = document.f.T1.value ;
	if (isNaN(cin) || (cin.length != 8) || (Number(cin.charAt(0)) > 1))
	{
		alert("CIN invalide !");return false;
	}
	var nom = document.f.T2.value ;
	if ((alpha(nom) == false) || (nom.length > 30) || (nom.length < 3))
	{
		alert("Nom invalide !"); return false;
	}
	var prenom = document.f.T3.value;
	if ((alpha(prenom) == false) || (prenom.length > 30) || (prenom.length < 3))
	{
		alert("Pr�nom invalide !"); return false;
	}
	var tel = document.f.T4.value;
	if ((numerique(tel) == false) || (tel.length != 8) || (tel.charAt(0) == "0"))
	{
		alert("Num�ro de t�l�phone invalide !"); return false;
	}
	if (document.f.D1.selectedIndex == 0)
	{
		alert("S�lection obligatoire d'un article !"); return false;
	}
	var prix = document.f.T6.value;
	if ((numerique(prix) == false) || (Number(prix) <= 0))
	{
	    alert("Le prix doit etre un entier strictement positif !"); return false;
	}
	return true;
}
function Espaces (Ch) 
{
	function effacer (ch,p,n)
    {
    	if ((ch.length < p) || (ch.length < p+n))
         {
         	return "";
         }
        else 
        {
        	return ch.slice(0,p) + ch.slice(p+n);
        }
    }
	function esp (ch)
	{	
		ch = ch.trim() ;
		while (ch.indexOf("  ") != -1)
		{
			ch = effacer(ch,ch.indexOf("  "),1) ;
		}
        return ch ;
	}
	function majus (ch)
	{
		var chm ="";
		do
		{
			if (ch.indexOf(" ") != -1)
			{   
				cha = ch.charAt(0).toUpperCase() + ch.slice(1,ch.indexOf(" ")+1);
			}
		    else 
		    {
		    	cha = ch.charAt(0).toUpperCase() + ch.slice(1);
		    }
			chm = chm + cha ;
			ch = effacer(ch,0,cha.length);
		} while ( ch != "");
		return chm;
	}
	return majus(esp(Ch));
}