-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeudi 15 Juin 2017 à 20:29
-- Version du serveur: 4.1.9
-- Version de PHP: 4.3.10
-- 
-- Base de données: `BDBAC2017`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `article`
-- 

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `Code` int(11) NOT NULL default '0',
  `Libelle` varchar(40) NOT NULL default '',
  `PrixBase` decimal(10,0) NOT NULL default '0',
  PRIMARY KEY  (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `article`
-- 

INSERT INTO `article` (`Code`, `Libelle`, `PrixBase`) VALUES (36, 'Luth du Hedi Jouini', 525);
INSERT INTO `article` (`Code`, `Libelle`, `PrixBase`) VALUES (45, 'Manuscrit d''Abou el Kacem Echebbi', 8520);
INSERT INTO `article` (`Code`, `Libelle`, `PrixBase`) VALUES (120, 'Les gants du gardien Attouga', 453);
INSERT INTO `article` (`Code`, `Libelle`, `PrixBase`) VALUES (312, 'Voiture 202 Bh', 25470);

-- --------------------------------------------------------

-- 
-- Structure de la table `client`
-- 

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `Cin` varchar(8) NOT NULL default '',
  `Nom` varchar(30) NOT NULL default '',
  `Prenom` varchar(30) NOT NULL default '',
  `Tel` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`Cin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `client`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `offre`
-- 

DROP TABLE IF EXISTS `offre`;
CREATE TABLE `offre` (
  `Cin` varchar(8) NOT NULL default '',
  `Code` int(11) NOT NULL default '0',
  `PrixPropose` decimal(10,0) NOT NULL default '0',
  PRIMARY KEY  (`Cin`,`Code`),
  KEY `Code` (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `offre`
-- 


-- 
-- Contraintes pour les tables exportées
-- 

-- 
-- Contraintes pour la table `offre`
-- 
ALTER TABLE `offre`
  ADD CONSTRAINT `offre_ibfk_2` FOREIGN KEY (`Code`) REFERENCES `article` (`Code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `offre_ibfk_1` FOREIGN KEY (`Cin`) REFERENCES `client` (`Cin`) ON DELETE CASCADE ON UPDATE CASCADE;
