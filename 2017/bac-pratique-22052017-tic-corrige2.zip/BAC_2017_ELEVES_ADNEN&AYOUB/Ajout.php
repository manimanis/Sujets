<?php
 
mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db('BDBAC2017') or die(mysql_error()); 

$code = $_POST["D1"] ;
$pp = $_POST["T6"] ; 

$req = "SELECT PrixBase FROM article WHERE (Code = '$code')" ; 
$res = mysql_query($req) or die(mysql_error()) ; 
$ligne = mysql_fetch_assoc($res) ;
if ($ligne["PrixBase"] > $pp)
{
	echo"<h2>Offre rejetée !</h2>"; die();
}

$cin = $_POST["T1"];
$nom = $_POST["T2"];
$prenom = $_POST["T3"];
$tel = $_POST["T4"];

$req = "SELECT * FROM client WHERE (Cin = '$cin')";
$res = mysql_query($req) or die(mysql_error());
if (mysql_num_rows($res) == 0)
{
	$req1 = "INSERT INTO client VALUES ('$cin','$nom','$prenom','$tel')";
	$req2 = "INSERT INTO offre VALUES ('$cin','$code',$pp)";
	$res1 = mysql_query($req1) or die(mysql_error());
    $res2 = mysql_query($req2) or die(mysql_error());
	if (($res1) && ($res2))
	{
		echo"<h2>Offre enregistré pour ce nouveau client !</h2>";  die();
	}
}	
else
{
	$req1 = "SELECT * FROM offre WHERE (cin = '$cin') AND (code = '$code')";
	$res1 = mysql_query($req1) or die(mysql_error());
	if (mysql_num_rows($res1) == 0)
	{
		$req2 = "INSERT INTO offre VALUES ('$cin','$code',$pp)";
		$res2 = mysql_query($req2) or die(mysql_error());
		if ($res2)
		{
			echo"<h2>Nouvelle offre enregistré !</h2>";
		}
	}
	else
	{
		$req2 = "UPDATE offre set PrixPropose = $pp WHERE (cin = '$cin')";
		$res2 = mysql_query($req2) or die(mysql_error());
		if ($res2)
		{
			echo"<h2>Mise à jour faite avec succès !</h2>"; die();
		}
	}
}
	
mysql_close();
?>