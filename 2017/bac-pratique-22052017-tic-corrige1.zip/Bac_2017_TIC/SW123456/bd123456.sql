-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 23, 2017 at 04:32 AM
-- Server version: 4.1.9
-- PHP Version: 4.3.10
-- 
-- Database: `bd123456`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `article`
-- 

CREATE TABLE IF NOT EXISTS `article` (
  `Code` int(11) NOT NULL default '0',
  `Libelle` varchar(35) NOT NULL default '',
  `PrixBase` int(11) NOT NULL default '0',
  PRIMARY KEY  (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `article`
-- 

INSERT INTO `article` VALUES (36, 'Luth du Hedi Jouini', 525);
INSERT INTO `article` VALUES (45, 'Manuscrit d''Abou el Kacem Echebbi', 8520);
INSERT INTO `article` VALUES (120, 'Les gants du gardien Attouga', 453);
INSERT INTO `article` VALUES (212, 'Voiture 202 Bh', 25470);

-- --------------------------------------------------------

-- 
-- Table structure for table `client`
-- 

CREATE TABLE IF NOT EXISTS `client` (
  `Cin` varchar(8) NOT NULL default '',
  `Nom` varchar(30) NOT NULL default '',
  `Prenom` varchar(30) NOT NULL default '',
  `Tel` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`Cin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `client`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `offre`
-- 

CREATE TABLE IF NOT EXISTS `offre` (
  `Cin` varchar(8) NOT NULL default '',
  `Code` int(11) NOT NULL default '0',
  `PrixPropose` int(11) NOT NULL default '0',
  PRIMARY KEY  (`Cin`,`Code`),
  KEY `Code` (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `offre`
-- 


-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `offre`
-- 
ALTER TABLE `offre`
  ADD CONSTRAINT `offre_ibfk_4` FOREIGN KEY (`Code`) REFERENCES `article` (`Code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `offre_ibfk_3` FOREIGN KEY (`Cin`) REFERENCES `client` (`Cin`) ON DELETE CASCADE ON UPDATE CASCADE;
