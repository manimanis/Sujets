//Fn qui vérifie si la variable Ch passée en paramètre, est composée uniquement par des Chiffres
function Numerique(Ch){
  for(var i=0; i<Ch.length; i++){
    if ((Ch.charAt(i)<"0") || (Ch.charAt(i)>"9")) return false;
  }
  return true; 
}
//Fonction qui vérifie si le paramètre Ch est composé uniquement par des Lettres
//Il est très facile à adapter cette fonction pour d’autre contrôle sur la composition des chaînes :
//Alphanumérique , Numérique, composée par les consonnes, par les signes de ponctuation...
//Il suffit de modifier la variable "Lettres"
function Alphabetique(Ch){
  var Lettres='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
  for(var i=0; i<Ch.length; i++){
    if(Lettres.indexOf(Ch[i].toUpperCase())<0) return false;
  }
  return true;  //Ce n’est pas nécessaire de retourner true
}
//Fonction Verif() appelée lors de l’envoie du formulaire (OnSubmit="return Verif()")
function Verif(){
    var Cin=F.T1.value;
    var Nom=F.T2.value;
    var Prenom=F.T3.value;
    var Tel=F.T4.value;
    var Prix=F.T5.value;

    if(Cin.length!=8 || (Cin.charAt(0)!='0' && Cin.charAt(0)!='1')|| !Numerique(Cin)){
        alert('Cin invalide'); return false;
    }
    if (Nom.length<3 || Nom.length>30 || !Alphabetique(Nom)){
        alert('Nom invalide') ; return false;
    }
    if (Prenom.length<3 || Prenom.length>30 || !Alphabetique(Prenom)){
        alert('Prénom invalide') ; return false;
    }
  
    if(Tel.length!=8 || Tel.charAt(0)==0 || !Numerique(Cin)){
        alert('Tel invalide') ; return false;
    }
    if(F.D1.selectedIndex==0){
        alert('Le choix d\'un article est obligatoire') ; return false;
    }
      if(!Numerique(Prix) || Prix<=0) {
        alert('Prix Invalide') ; return false;
    }
}
function Espaces(Ch){
   var Res=Ch.charAt(0); //Mettre dans Res le Premier caractère dans Ch

   //On parcourt Ch en ajoutant ses caractères à Res sans laisser les espaces superflus :
   //Lors du parcours : Si le caractère de Ch n'est pas un Espace --> on l'ajoute à Res
   //Si le caractère de Ch est un espace, on ne l'ajoute à Res que si le dernier caractère
   //de Res n'est pas un Espace (pour ne pas avoir des Espaces consécutifs dans Res)
   for(i=1; i<Ch.length; i++){ 
      if(Ch.charAt(i)!=' ' || (Ch.charAt(i)==' ' && Res.charAt(Res.length-1)!=' ')){
         Res=Res+Ch.charAt(i)
      }
   }

   //Note: On peut utiliser "Res[0]" au lieu de "Res.charAt(0)" mais ça ne fonctionne
   //pas sur tous les navigateurs
   
   // Si le premier caractère de Res est un Espace, on le supprime
   if(Res.charAt(0)==' '){
      Res=Res.substr(1)
   }

   // Si le dernier caractère de Res est un Espace, on le supprime
   if(Res.charAt(Res.length-1)==' '){
      Res=Res.substr(0,Res.length-1)
   }

   //Convertir la première lettre de chaque mot de Res en Majus
   Res=Res.charAt(0).toUpperCase()+Res.substr(1)
   //Attention: Res.charAt(0)=Res.charAt(0).toUpperCase() génère une erreur
   //parce que charAt() donne accès à un caractère EN LECTURE SEULE.

   //On parcourt Res et si on trouve un espace, on convertit le caractère qui le 
   //succède en Majus (il sera la première lettre d'un mot)
   for(i=1; i<Res.length; i++){
       if (Res.charAt(i)==' '){ //Si on trouve un espace on copie 1ère partie de Res
      Res=Res.substr(0,i+1)+ //Du premier caractère jusqu'au caractère Espace
        Res.charAt(i+1).toUpperCase()+ //+ Plus la 1ère lettre du mot, convertie en Majus
        Res.substr(i+2); //+ Plus le reste de la chaîne Res
     }
   }
   return Res
}
