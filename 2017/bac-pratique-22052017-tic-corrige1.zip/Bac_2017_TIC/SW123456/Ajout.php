<?php
//L'accès à ce fichier "Ajout.php" doit passer obligatoirement par 
//la page "Ajout.html". 
//Pour s’assurer de ça :
//On vérifie l'existence de la case $_POST["B1"], avec "B1" est
//le nom du bouton "Valider" dans "Ajout.html"
if(!isset($_POST["B1"])){ //Si $_POST["B1"] n'existe pas...
        //...On redirige le navigateur vers Ajout.html
    header('location: Ajout.html');
    die(); //et on quitte le script Php
}

echo "<meta charset='utf-8'>";

//Récupération des Champs T1, T2, T3 , T4, D1 et T5
$Cin=$_POST["T1"];
$Nom=$_POST["T2"];
$Prenom=$_POST["T3"];
$Tel=$_POST["T4"];
$CodeArticle=$_POST["D1"];
$Prix=$_POST["T5"];

//Connexion à MySQL
mysql_connect("localhost","root") or exit(mysql_error());

//Sélection de la BD
mysql_select_db("BD123456") 
  or die("Vous devez préalablement créer la Base 'BD123456' - ".mysql_error());

//Pour ce qui suit: 
//  - $Q utilisée pour les requêtes ([Q] ==> [Q]uery)
//  - $R utilisée pour les ressources ([R] ==> [R]essource)

//Vérification de la validité de l'offre: Le Prix doit être ≥ PrixBase
$R=mysql_query("SELECT PrixBase FROM Article WHERE Code='$CodeArticle'");
$T=mysql_fetch_array($R);

//Si Prix<PrixBase on quitte le script en affichant le message :"Offre Rejetée"
if($Prix<$T[0]) exit ("Offre Rejetée"); 

//Vérification de l'existence du Client
$R=mysql_query("SELECT * FROM Client WHERE Cin='$Cin'") or die(mysql_error());

if(mysql_num_rows($R)==0){ //Si le Client ne se trouve pas dans la base

        //... on l'ajoute à la Table "Client"
    $Q="INSERT INTO Client VALUES('$Cin','$Nom','$Prenom','$Tel')";
    $R=mysql_query($Q) or die("Problème d'insertion du client: ".mysql_error());

        //... puis on insère son offre
    $Q="INSERT INTO Offre VALUES('$Cin','$CodeArticle',$Prix)";
    $R=mysql_query($Q) or die("Problème d'ajout de la nouvelle offre: ".mysql_error());

        //... et enfin, on affiche le message et on quitte le script
    if(mysql_affected_rows()) exit ("Offre Enregistrée pour ce nouveau client");

} 

//si on atteind cette partie du script, c'est que le client Existe
//On a pu utiliser "Else" ici, mais ce n'est pas nécessaire puisqu'on a utiliser 
//la fonction "Exit" lors de l'affichage du message de confirmation de l'ajout
//de l'offre pour le nouveau client (Plus haut)

//On vérifie alors si le Client a déjà déposé une offre pour le même article
$R=mysql_query("SELECT * FROM Offre Where Code='$CodeArticle' AND Cin='$Cin'");

if(mysql_num_rows($R)==0){ //S'il n'a pas une ancienne offre pour cet article
        //...on ajoute sa nouvelle offre à la table "Offre"
    $R=mysql_query("INSERT INTO Offre VALUES('$Cin','$CodeArticle',$Prix)");

        //...et on affiche un message de la réussite de l’ajout de l’offre
        //On peut aussi utiliser "Exit" au lieu d'"echo" pour quitter 
        //le script après l'affichage du message,  et on n'aura pas 
        //besoin d'utiser "Else" (plus bas)
    if(mysql_affected_rows()) echo ("Nouvelle Offre Enregistrée");

} else { //sinon = Le client a déja une offre pour ce même article

        // -->On met à jour le prix de son offre dans la table
    $Q="UPDATE Offre SET PrixPropose=$Prix 
        WHERE Code='$CodeArticle' AND Cin='$Cin'";
    $R=mysql_query($Q) or exit(mysql_error());
        //...et on affiche un message de succès la mise à jour
    echo ("Mise à jour faite avec Succès");
}

?>
