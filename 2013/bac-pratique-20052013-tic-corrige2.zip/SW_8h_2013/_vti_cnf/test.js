vti_encoding:SR|utf8-nl
vti_author:SR|POSTE1\\enseignant
vti_modifiedby:SR|POSTE1\\enseignant
vti_timelastmodified:TR|20 May 2013 15:32:59 -0000
vti_timecreated:TR|20 May 2013 13:34:48 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|saisie.html
vti_nexttolasttimemodified:TW|20 May 2013 15:32:35 -0000
vti_cacheddtm:TX|20 May 2013 15:32:59 -0000
vti_filesize:IR|1099
