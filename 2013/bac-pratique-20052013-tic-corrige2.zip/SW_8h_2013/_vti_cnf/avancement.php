vti_encoding:SR|utf8-nl
vti_author:SR|POSTE1\\enseignant
vti_modifiedby:SR|POSTE1\\enseignant
vti_timelastmodified:TR|20 May 2013 15:52:23 -0000
vti_timecreated:TR|20 May 2013 15:15:40 -0000
vti_title:SR|Nouvelle page 1
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|menu.html
vti_nexttolasttimemodified:TW|20 May 2013 15:52:09 -0000
vti_cacheddtm:TX|20 May 2013 15:52:09 -0000
vti_filesize:IR|874
vti_cachedtitle:SR|Nouvelle page 1
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|css/css.css
vti_cachedsvcrellinks:VX|FQUS|css/css.css
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=windows-1252
vti_charset:SR|windows-1252
