
function verif(f1)
{
    ch=f1.T1.value;
    if( ch.length!=8)
    {
       alert('Ncin est compos� de 8 chiffres et commen�ant par 0 et 1');
       return false;
       }
    if((ch.charAt(0)!='0')&&(ch.charAt(0)!='1'))
       {
       alert('Ncin est compos� de 8 chiffres et commen�ant par 0 et 1');
       return false;
       }
 if(f1.D1.value==0)
 {
   
       alert("La s�l�ction d'un �quipement est obligatoire");
       return false;
       }

   
   if((f1.D2.value!=1)&&(f1.D2.value!=2)&&(f1.D2.value!=3)&&(f1.D2.value!=4)&&(f1.D2.value!=5))
   {
   
       alert("La s�l�ction d'une dur�e est obligatoire");
       return false;
       }

}


