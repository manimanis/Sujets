<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Nouvelle page 1</title>
</head>

<body>
<?
mysql_connect("localhost","root","");
    mysql_select_db("bd333333");
    $a=$_POST['T1'];
    $b=$_POST['D1'];
   
    $req="select * from client where ncin='$a'";
    $r= mysql_query($req);
    if(mysql_num_rows($r)== 0)
         echo "<font size=6 red='color'><center> Ncin inexistant </center></font>";
    else
    {  
       $req="select  *  from equipement where ((ref='$b')and(disponible='O')) ";
       
       $r= mysql_query($req);
       
            
       if(mysql_num_rows($r)!=0)
            echo "<font size=6 red='color'><center>Equipemet d�ja retourn�!!!!!</center></font>";
       else
         {
           $req="update equipement set disponible='O' where ref='$b'";
           $r= mysql_query($req);
           
           $d=date("Y-m-d H:i:s"); 
           $req1="update location set dateret='$d' where (ncinclient='$a') and (refequipement='$b')";
           $r1= mysql_query($req1);
            if(($r!=NULL) && ($r1!=NULL))
                   	echo "<font size=6 red='color'><center> op�ration termin�e avec succ�s </center></font>";
         }
      }
     ?>
       
</body>

</html>
