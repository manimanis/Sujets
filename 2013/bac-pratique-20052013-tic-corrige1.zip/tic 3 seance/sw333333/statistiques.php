<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Nouvelle page 1</title>
</head>

<body>
<?
mysql_connect("localhost","root","");
    mysql_select_db("bd333333");
   
   
   $req="select * from location where (dateret!='0000-00-00 00:00:00') ";

    $r= mysql_query($req);
    if(mysql_num_rows($r)== 0)
           echo "<font size=6 red='color'><center> Pas encore de location!!! </center></font>";
     else
     {   
         $req="select libelle,prixheure,dateloc,dateret from equipement,location where(ref=refequipement)and(dateret!='0000-00-00 00:00:00') ";

         $r= mysql_query($req);

         echo "<table border=1 align='center'>";
         echo "<tr><td><b>libelle</b></td><td><b>Date location</b></td><td><b>date retour</b></td><td><b>PrixHeure</b></td><td><b>Montant</b></td></tr>";
         
         
        
         while($t=mysql_fetch_array($r))
           {
              echo "<tr><td>".$t[0]."</td><td>".$t[2]."</td><td>".$t[3]."</td><td>".$t[1]."</td>";
              $temp2=strtotime($t[3]);
              $temp1=strtotime($t[2]);
              $duree=($temp2-$temp1)/3600;
              $m=$duree * $t[1];
              echo "<td>".$m."</td></tr>";
              
              
           }
           echo "</table>";
       }
    ?>
              
</body>

</html>
