<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Nouvelle page 1</title>
</head>

<body>
<?
    mysql_connect("localhost","root","");
    mysql_select_db("bd333333");
    $a=$_POST['T1'];
    $b=$_POST['D1'];
    $c=$_POST['D2'];
    $req="select * from client where ncin='$a'";
    $r= mysql_query($req);
    if(mysql_num_rows($r)== 0)
         echo "<font size=6 red='color'><center> Ncin inexistant </center></font>";
    else
    {
         $req="select * from equipement where ref='$b' and disponible='N'";
         $r= mysql_query($req);
    		if(mysql_num_rows($r)!= 0)
              echo "<font size=6 red='color'><center> Equipement non disponible </center></font>";
            else
              {
                  $d=date("Y-m-d H:i:s");
                  $dseconde=strtotime($d);
                  $duree=$c*3600;
                  $somme= $duree + $dseconde;
                  $e=date("Y-m-d H:i:s",$somme);
                  $req="insert into location values ('$a','$b','$d','$e')";
                  $r= mysql_query($req);
				  $req1="update equipement set disponible='N' where ref='$b'";
                  $r1= mysql_query($req1);
                  if(($r!=NULL) && ($r1!=NULL))
                   	echo "<font size=6 red='color'><center> op�ration termin�e avec succ�s </center></font>";
               }
      }
      
  ?>

</body>

</html>
