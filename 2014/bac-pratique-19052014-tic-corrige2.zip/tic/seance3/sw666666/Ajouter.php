<html>
<body "bgcolor="#CCFF99">
<?
mysql_connect("localhost","root","");
    mysql_select_db("bd666666");
    $a=$_POST['T1'];
    $b=$_POST['T2'];
    $c=$_POST['D1'];
	$d=$_POST['S1'];
    $req="select * from internaute where pseudo='$a'";
    $r= mysql_query($req);
    if(mysql_num_rows($r)== 0)
	   echo "<font color='red' size=6><center> Pseudo erron�</center></font>";
	   else
	   {
	     $e=date("Y-m-d H:i:s");
		 $req="insert into avis values('$a','$c','$e','$b','$d')";
		  $r= mysql_query($req);
		  if ($r==NULL)
		     echo "<font color='red' size=6><center> Requ�te a echou�e</center></font>";
			 else
			  echo "<font color='red' size=6><center> Insertion termin�e avec succ�s!!</center></font>";
			  }
			  ?>
			  </body>
			  </html>