function verif1()
{
  if (f1.T1.value.length!=6)
   { alert('Le pseudo est compos� de 6 caract�res alphanum�rique!!');
     return false;
	 }
	 if (f1.D1.selectedIndex==0)
	 { alert("La s�l�ction d'un logiciel est obligatoire!!");
     return false;
	 }
	 note=Number(f1.T2.value);
	 if ( (a<0)|| (a>20))
	 { alert("La note est entre 0 est 20!!");
     return false;
	 }
	 }
	 
	 function verif2()
{
  
	 if (f1.D1.selectedIndex==0)
	 { alert("La s�l�ction d'un logiciel est obligatoire!!");
     return false;
	 }
	 
	 } 
	 