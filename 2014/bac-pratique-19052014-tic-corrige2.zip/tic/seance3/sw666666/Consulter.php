<html>
<body "bgcolor="#CCFF99">
<?
mysql_connect("localhost","root","");
    mysql_select_db("bd666666");
    
    $a=$_POST['D1'];
	
	$req="select * from logiciel l, avis a where (a.idlog=l.idlog) and (a.idlog='$a')";
	
	$r=mysql_query($req);
	if(mysql_num_rows($r)!=0)
	{   while($t=mysql_fetch_array($r)){
	     echo "libelle: ".$t['libelle']." |  Description: ".$t['description']." | <br> ";
		 echo "DateAvis: ".$t['dateavis']." |  Pseudo: ".$t['pseudo']." | Etoiles:   ";
		 echo $t['note'];
		 $k=$t['note'];
		 $i=1;
		while($i<$k) 
		{   echo "*";
		     $i++;
			 }
		    
		     echo "*";
			 echo "<br><br>";
			 }
			 }
		?>
		</body>
		</html>