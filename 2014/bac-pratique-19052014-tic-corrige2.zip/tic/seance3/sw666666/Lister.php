<html>
<body bgcolor="#CCFF99">
<?
mysql_connect("localhost","root","");
    mysql_select_db("bd666666");
    
   
	$req="select libelle ,avg(note) as moy from logiciel l, avis a where (l.idlog=a.idlog) group by (l.idlog)asc";
	$r=mysql_query($req);
	if(mysql_num_rows($r)!=0)
	{   while($t=mysql_fetch_array($r)){
	          echo "libelle: ".$t['libelle']." |  Moyenne arithm�tique: ".$t['moy']." | <br> ";
			  }
			  }
			  ?>
			  <a href="index.html">Retour</a>
			  </body>
			  </html>