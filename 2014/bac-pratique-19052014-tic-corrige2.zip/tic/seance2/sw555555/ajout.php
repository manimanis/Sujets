<?
mysql_connect("localhost","root","");
mysql_select_db("bd555555");
$a=$_POST['T1'];
$b=$_POST['D1'];

$c=$_POST['R1'];
 //if ($c=="1")
   //  $c=3;
	// else
	  // if($c=="2")
	     //$c=6;
		 //else
		   // $c=12;

$req="select * from abonnee where cin='$a'";
$r=mysql_query($req);
if(mysql_num_rows($r)==0)
 echo "Abonn� inexistant!!";
 else
 {
     $d=date("Y-m-d");
	 $req="select * from abonnement where cin='$a' and dateech<='$d'";
	 $r=mysql_query($req);
     if(mysql_num_rows($r)!=0)
            echo "Vous �tes d&�ja abonn� � cette revue!!";
			else
			{   $req="select * from revue where code='$b'";
	             $r=mysql_query($req);
			   while($t=mysql_fetch_array($r)){
			   
			   $de=date("Y-m-d",strtotime($d)+($c*30*24*3600));
			  
			   $m=$t['prixmens']*$c;
			   
			   $req1="insert into abonnement values('$a','$b','$d','$de')";
			    $r1=mysql_query($req1);
				if($r1==NULL)
				  echo "La requ�te � echou�e";
				  else
				   echo "insertion termin�e avec succ�s";
				   }
				}
			}
?>