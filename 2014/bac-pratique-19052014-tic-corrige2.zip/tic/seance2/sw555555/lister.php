<html>
<body bgcolor="#CCFF99">
<?
mysql_connect("localhost","root","");
mysql_select_db("bd555555");


$req="select * from revue";
$r=mysql_query($req);
if(mysql_num_rows($r)==0)
 echo "Table vide!";
 else
   {
     while($t=mysql_fetch_array($r)){
	      echo "<b>code ".$t['code']."  Titre ".$t['titre']."prix mensuels ".$t['prixmens']."</b><br><br>";
			   
      

		  }
		  }
		  ?>
		  </body>
		  </html>
	   