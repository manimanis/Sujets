<?
mysql_connect("localhost","root","");
mysql_select_db("bd555555");
$a=$_POST['T1'];


$c=$_POST['S1'];

$req="select * from abonnee where cin='$a'";
$r=mysql_query($req);
if(mysql_num_rows($r)==0)
 echo "Abonn� inexistant!!";
 else
   {
      $req="update abonnee set adresse='$c' where cin='$a'";
	  $r=mysql_query($req);
	  if($r==NULL)
	    echo "La requ�te � echou�e!!";
		else
		  echo "Modification termin�e avec succ�s!!";
		  }
		  ?>
	   