<?php
$cin=$_POST['cin'];
$adr=$_POST['adr'];
mysql_connect('localhost','root','','');
mysql_select_db('BD143408');
$req="select Cin from abonne where Cin='$cin'";
$res=mysql_query($req);
$nb=mysql_num_rows($res);
if($nb==0)
echo('Abonn� inexistant');
else
{
$req="update abonne set Adresse='$adr' where Cin='$cin'";
mysql_query($req);
echo('modification avec succes');
}
?>