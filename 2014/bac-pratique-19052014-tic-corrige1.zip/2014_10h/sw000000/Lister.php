<?php
mysql_connect('localhost','root','','');
mysql_select_db('BD143408');
$req="select * from revue";
$res=mysql_query($req);
echo("<table border='2'><tr><td>Titre</td><td>Montant</td></tr>");
while($l=mysql_fetch_array($res))
{
echo("<tr><td>");
echo($l['Titre']);
echo("</td><td>");
echo($l['PrixMens']);
echo("</td></tr>");
}
}
?>