<?php
$cin=$_POST['cin'];
$tit=$_POST['tit'];
$dur=$_POST['R1'];
mysql_connect('localhost','root','','');
mysql_select_db('BD143408');
$req="select Cin from abonne where Cin='$cin'";
$res=mysql_query($req);
$nb=mysql_num_rows($res);
if($nb==0)
echo('Abonn� inexistant');
else
{
$req="select Code from revue where Titre='$tit'";
$res=mysql_query($req);
$l=mysql_fetch_array($res);
$cod=$l['Code'];
$req="select Cin from abonnement where Cin='$cin' and DateEch>NOW() and Code='$cod'";
$res=mysql_query($req);
$nb=mysql_num_rows($res);
if($nb!=0)
echo('Vous �tes d�ja abonn� a cette revue');
else
{
$req="select Code , PrixMens from revue where Titre='$tit'";
$res=mysql_query($req);
$l=mysql_fetch_array($res);
$cod=$l['Code'];
$prix=$l['PrixMens'];
$m=$prix*$dur;
$dat=date("Y-m-d",strtotime("+$dur month"));
$d='NOW()';
$req="insert into abonnement values('$cin','$cod',$d,'$dat')";
mysql_query($req);
echo("Ajout aves succes avec Montant � payer : $m et votre date d'�chance de l'abonnemet est $dat");
}
}
?>