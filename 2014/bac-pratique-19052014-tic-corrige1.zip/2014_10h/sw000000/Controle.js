function verif1()
{
ch1=document.f.cin.value;
ch2=document.f.tit;
ch3=document.f.R1;
if(ch1=='' || ch1.length!=8 || ch1.charAt(0)!=0 && ch1.charAt(0)!=1 || isNaN(ch1))
alert('verifier votre cin');
if(ch2.selectedIndex==0)
alert('choisir un titre');
if(document.f.R1[0].checked==false && document.f.R1[1].checked==false && document.f.R1[2].checked==false)
alert('choisir une durr�e');
}
function verif2()
{
ch1=document.f.cin.value;
ch2=document.f.adr.value;
if(ch1=='' || ch1.length!=8 || ch1.charAt(0)!=0 && ch1.charAt(0)!=1 || isNaN(ch1))
alert('verifier votre cin');
if(ch2=='')
alert('verifier vore adress');
}