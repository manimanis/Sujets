

function alpha(ch){
	ok=true
	i=0
	while ((i<ch.length)&&(ok==true)){
		c=ch.charAt(i).toUpperCase()
		if ((c<"A")||(c>"Z")){
		ok=false}
	i++}
return ok}


function verif1(){
	perm=f.perm.value
	nom=f.nom.value
	pre=f.pre.value
	if (perm==""){
		alert("Le N° permis est vide!");
	return false;}
	ch1=perm.substring(0,2);
	ch2=perm.substring(3,perm.length);
	if (isNaN(ch1)||(isNaN(ch2))){
		alert("Le N° Permis doit etre sous la former 'xx/xxxxx!'(chaque x représente un chiffre) ");
	return false;}
	if (perm.charAt(2)!="/"){
		alert("Le 3éme caractere de N° Permis doit etre '/'! ");
	return false;}
	if (perm.length!=8){
		alert("Le longeur de N°Permis doit etre 8!");
	return false;}
	if ((nom=="")||(alpha(nom)==false)){
		alert("Verifier que le nom est Alphabetique!");
	return false;}
	if ((nom.length<3)||(nom.length>20)){
		alert("Le Longeur de champ Nom doit etre comprise entre 3 et 20!");
	return false;}
	if ((pre=="")||(alpha(pre)==false)){
		alert("Verifier que le Prénom est Alphabetique!");
	return false;}
	if ((pre.length<3)||(pre.length>20)){
		alert("Le Longeur de champ Prénom doit etre comprise entre 3 et 20!");
	return false;}
	if((f.R1[0].checked==false)&&(f.R1[1].checked==false)){
	alert("Il faut choisir le genre!");
	return false;}
	
	
}



function verif2(){
	perm=f.perm.value
	sec=f.sec.value
	cond=f.cond.value
	conf=f.conf.value
	if (perm==""){
		alert("Le N° permis est vide!");
	return false;}
	ch1=perm.substring(0,2);
	ch2=perm.substring(3,perm.length);
	if (isNaN(ch1)||(isNaN(ch2))){
		alert("Le N° Permis doit etre sous la former 'xx/xxxxx!'(chaque x représente un chiffre) ");
	return false;}
	if (perm.charAt(2)!="/"){
		alert("Le 3éme caractere de N° Permis doit etre '/'! ");
	return false;}
	if (perm.length!=8){
		alert("Le longeur de N°Permis doit etre 8!");
	return false;}
	x=f.D1.selectedIndex
	if (x==0){
		alert("Il faut choisir le modèle testé!");
	return false;}
	if ((sec=="")||(isNaN(sec))){
		alert("La note de Sécurité doit etre un chiffre numérique!");
	return false;}
	if ((sec<1)||(sec>5)){
		alert("La note de Sécurité doit etre un entier entre 1 et 5!");
	return false;}
	if ((cond=="")||(isNaN(cond))){
		alert("La note de Conduite doit etre un chiffre numérique!");
	return false;}
	if ((cond<1)||(cond>5)){
		alert("La note de Conduite doit etre un entier entre 1 et 5!");
	return false;}
	if ((conf=="")||(isNaN(conf))){
		alert("La note de Confort doit etre un chiffre numérique!");
	return false;}
	if ((conf<1)||(conf>5)){
		alert("La note de Confort doit etre un entier entre 1 et 5!");
	return false;}
	if (f.C1.checked==false){
		alert("Verifier que vous etes pas un robot!")
	return false;}
}