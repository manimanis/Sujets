<?php
mysql_connect("localhost","root","")or die ('problem CNX!');
mysql_select_db("bd2022")or die ('problem BASE!');

$res=mysql_query("SELECT modelevoiture.libelle,AVG(evaluation.securite),AVG(evaluation.conduite),AVG(evaluation.confort),Count(*) FROM modelevoiture,evaluation WHERE modelevoiture.idModele = evaluation.idModele AND YEAR(DATE(NOW())) = YEAR(DATE(dateTest)) GROUP BY modelevoiture.libelle;") or die('problem REQ ');
if (mysql_num_rows($res)==0){
echo("Aucun evaluation a ete enregistr�e cette ann�e !");}
else{
	
	echo("<table border='1' width='100%'>
	<tr>
		<td width='363'>
		<p align='center'><b><font size='4' color='#808080'>Mod�le</font></b></td>
		<td width='244'>
		<p align='center'><b><font color='#808080' size='4'>S�curit�</font></b></td>
		<td width='232'>
		<p align='center'><b><font size='4' color='#808080'>Conduite</font></b></td>
		<td width='224'>
		<p align='center'><b><font color='#808080' size='4'>Confort</font></b></td>
		<td>
		<p align='center'><b><font color='#808080' size='4'>Nbr tests</font></b></td>
	</tr>");
	while ($t=mysql_fetch_array($res)){
		echo("
	<tr>
		<td width='363'><p align='center'><b><font size='4' color='#666666'>$t[0]</font></b></td></td>
		<td width='244'><p align='center'><b><font size='4' color='#800080'>$t[1]</font></b></td></td>
		<td width='232'><p align='center'><b><font size='4' color='#800080'>$t[2]</font></b></td></td>
		<td width='224'><p align='center'><b><font size='4' color='#800080'>$t[3]</font></b></td></td>
		<td><p align='center'><b><font size='4' color='#00FF00'>$t[4]</font></b></td></td>
	</tr>");
	}
echo("</table>");
}

?>