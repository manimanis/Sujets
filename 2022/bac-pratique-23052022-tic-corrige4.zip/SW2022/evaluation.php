<?php
mysql_connect("localhost","root","")or die ('problem CNX!');
mysql_select_db("bd2022")or die ('problem BASE!');

$p=$_POST['perm'];
$mod=$_POST['D1'];
$sec=$_POST['sec'];
$cond=$_POST['cond'];
$conf=$_POST['conf'];

$res=mysql_query("SELECT * FROM testeur WHERE numPermis = '$p';")or die ('problem REQ 1');
if (mysql_num_rows($res)==0){
	echo("Testeur non inscrit");
}
else{
	$res1=mysql_query("SELECT * FROM evaluation WHERE numPermis = '$p' AND idModele = $mod		;")or die ('problem REQ2');
	if (mysql_num_rows($res1)!=0){
		echo("Vous avez d�j� tets� ce mod�le");
	}else{
		$res2=mysql_query("INSERT INTO evaluation VALUES ('$p',$mod,NOW(),'$sec','$cond','$conf');") or die ('problem REQ3');
		echo("Evaluation enregistr�e avec succ�s");
	}
}
?>