<?php
mysql_connect("localhost","root","")or die ('problem CNX!');
mysql_select_db("bd2022")or die ('problem BASE!');

$p=$_POST['perm'];
$n=$_POST['nom'];
$pr=$_POST['pre'];
$g=$_POST['R1'];

$res=mysql_query("SELECT * FROM testeur WHERE numPermis = '$p';")or die ('problem REQ 1');
if (mysql_num_rows($res)!=0){
	echo("Num�ro de permis d�j� existant");
}
else{
	$res1=mysql_query("INSERT INTO testeur VALUES('$p','$n','$pr','$g')	;")or die ('problem REQ2');
	echo("Enregistrement fait avec succ�s");
}
?>