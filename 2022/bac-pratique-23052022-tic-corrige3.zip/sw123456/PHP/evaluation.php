<?php

mysql_connect('localhost','root','') or die ("problème de connexion..");
mysql_select_db("bd123456");


$np=$_POST['permis'];
$idm=$_POST['modele'];
$s=$_POST['securite'];
$con=$_POST['conduite'];
$conf=$_POST['confort'];
$datetest=date("Y-m-d H:m:s", strtotime("Now")); 

$req="select * from testeur where numpermis='$np';"; 
$result=mysql_query($req); 

if(mysql_num_rows($result)>0){
    $req="select * from evaluation where numpermis='$np' and idmodele=$idm;"; 
    $result=mysql_query($req); 
    if(mysql_num_rows($result)==0) {
        $req="insert into evaluation values ('$np',$idm,'$datetest',$s,$con,$conf);";
        $result=mysql_query($req); 
        if($result)  echo '<script>alert("Evaluation enregistré avec succés");</script>';
    }
    else 
    {
    echo '<script>alert("Vous avez déja tester ce modele");</script>';
    }  
   
} else {
    echo '<script>alert("Testeur non inscrit");</script>';
}

?>