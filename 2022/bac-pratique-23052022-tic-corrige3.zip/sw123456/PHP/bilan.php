<?php
    mysql_connect('localhost','root','') or die ("problème de connexion..");
    mysql_select_db("bd123456");

    $req="select libelle , avg(securite), avg(conduite), avg(confort), count(numpermis) 
    from modelevoiture m, evaluation e where m.idmodele=e.idmodele group by e.idmodele;";

    $result=mysql_query($req); 

    echo '
    <table border="1px" >
    <tr>
    <th>Modèle</th>
    <th>Sécurité</th>
    <th>Conduite</th>
    <th>Confort</th>
    <th>Nbr tests</th>
    </tr>'; 
    while ($row=mysql_fetch_array($result)){
        echo'<tr>'; 
        echo '<td>'.$row[0].'</td>';  
        echo '<td>'.$row[1].'</td>';  
        echo '<td>'.$row[2].'</td>';  
        echo '<td>'.$row[3].'</td>';  
        echo '<td>'.$row[4].'</td>';  
        echo'</tr>';
    }
    echo '</table>';


?>