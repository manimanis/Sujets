<?php

mysql_connect('localhost','root','') or die ("problème de connexion..");
mysql_select_db("bd123456");

$np=$_POST['permis'];
$n=$_POST['nom'];
$p=$_POST['prenom'];
$g=$_POST['genre'];

$req="select * from testeur where numpermis='$np';"; 
$result=mysql_query($req); 

if(mysql_num_rows($result)==0){
    $req="insert into testeur values ('$np','$n','$p','$g');";
    $result=mysql_query($req); 
    if($result) {
        echo '<script>alert("Enregistrement fait avec succés");</script>';
    }
} else {
    echo '<script>alert("Numéro de permis déja existant");</script>';
}

?>