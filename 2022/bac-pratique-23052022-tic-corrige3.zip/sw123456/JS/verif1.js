function verif1() {
    nump = f.permis.value;
    n = f.nom.value;
    p = f.prenom.value;
    g = f.genre.value;

    controle_num_permis = nump.length == 8 && nump.indexOf('/') == 2 && nombre_pure(nump);
    controle_nom = n.length >= 3 && n.length <= 20 && alpha(n);
    controle_prenom = p.length >= 3 && p.length <= 20 && alpha(p);
    controle_genre = g!='';

    if (!controle_num_permis) {
        alert("Merci de verifier votre numéro de permis ..");
        return false;

    }
    if (!controle_nom) {
        alert("Merci de verifier votre nom ..");
        return false;

    }
    if (!controle_prenom) {
        alert("Merci de verifier votre prénom ..");
        return false;

    }
    if (!controle_genre) {
        alert("Merci de verifier votre genre ..");
        return false;

    }

    return true;

}

function nombre_pure(_n) {

    number = "0123456789";

    for (i = 0; i < _n.length; i++) {

        if ((number.indexOf(_n[i]) == -1) && (_n[i] != '/')) {
            return false;
        }
    }
    return true;

}

function alpha(_str) {

    for (i = 0; i < _str.length; i++) {
        if ((_str[i].toUpperCase() < 'A') || (_str[i].toUpperCase() > 'Z')) {
            return false;
        }
    }

    return true;

}