function verif2() {
    nump = f.permis.value;
    modele = f.modele.value;
    sec = f.securite.value;
    cond = f.conduite.value;
    conf = f.confort.value;
    rob = f.robot;

    controle_num_permis = nump.length == 8 && nump.indexOf('/') == 2 && nombre_pure(nump);
    controle_modele = modele != '0';
    controle_securite = sec != '' && Number(sec) <= 5 && Number(sec) >= 0;
    controle_conduite = cond != '' && Number(cond) <= 5 && Number(cond) >= 0;
    controle_confort = conf != '' && Number(conf) <= 5 && Number(conf) >= 0;
    controle_robot = rob.checked;

    if (!controle_num_permis) {
        alert("Merci de verifier votre numéro de permis ..");
        return false;
    }
    if (!controle_modele) {
        alert("Merci de séléctioner un modèle ..");
        return false;
    }
    if (!controle_securite) {
        alert("Merci de verifier la valeur de champ sécrité ..");
        return false;
    }
    if (!controle_conduite) {
        alert("Merci de verifier la valeur de champ conduite ..");
        return false;
    }
    if (!controle_confort) {
        alert("Merci de verifier la valeur de champ confort ..");
        return false;
    }
    if (!controle_robot) {
        alert("Test de robot est obligatoire ..");
        return false;
    }

    return true;


}

function nombre_pure(_n) {

    number = "0123456789";

    for (i = 0; i < _n.length; i++) {

        if ((number.indexOf(_n[i]) == -1) && (_n[i] != '/')) {
            return false;
        }
    }
    return true;

}