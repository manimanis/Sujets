<?
mysql_connect("localhost","root","");
mysql_select_db("bd1111");
$a=$_POST['T1'];
$b=$_POST['T2'];
$c=$_POST['T3'];
$d=$_POST['T4'];
$e=$_POST['R1'];
$req="select * from pilote where idavion='$a'";
$r=mysql_query($req);
if(mysql_num_rows!=0)
echo "<center><font size=7 color='red'>Pilote existant </font></center>";
else
{$req="insert into pilote values('$a','$b','$c','$e','$d'";
$r=mysql_query($req);
 if($r==NULL)
 echo "<center><font size=7 color='red'>La requête a echouée</font></center>";
 else
 echo "<center><font size=7 color='red'>Insertion terminée avec succès </font></center>";
 
?>