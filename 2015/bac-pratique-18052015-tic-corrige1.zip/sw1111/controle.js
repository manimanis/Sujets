function verif(){
if(f.T1.value.length!=4){
 alert('Le champs ,est compos� de 4 caract�res!');
   return false;
   }

ch1=f.T1.value.charAt(0)+f.T1.value.charAt(1);
if(isNaN(ch1)==false){
   alert('Les deux premiers caract�res sont des lettres!');
   return false;
   }
 ch1=f.T1.value.charAt(2)+f.T1.value.charAt(3);
if(isNaN(ch1)==true){
   alert('Les deux derniers caract�res sont des chiffres!');
   return false;
   }
if(f.T2.value==''){
 alert('Le champs est non vide!');
   return false;
   }
if(f.T3.value==''){
 alert('Le champs est non vide!');
   return false;
   }
ch=f.T4.value;
if(ch.indexOf('@',ch)==-1){
 alert('Email invalide!');
   return false;
   }
   p=ch.indexOf('@',ch);
 ch1=ch.substring(0,p-1);
  if(isNaN(ch1)==false){
 alert('doit comporter des lettres alphab�tiques!');
   return false;
   }
   if(ch.indexOf('.',ch)==-1){
 alert('Email invalide!');
   return false;
   }
    p=ch.indexOf('.',ch);
 ch3=ch.substring(p+1,ch.length(ch)-1);
  if(isNaN(ch3)==false){
 alert('doit comporter des lettres alphab�tiques!');
   return false;
   }
 p1=ch.indexOf('@',ch);
 p2=ch.indexOf('.',ch);
 ch2=ch.substring(p1+1,p2-1);

if(isNaN(ch2)==false){
 alert('doit comporter des lettres alphab�tiques!');
   return false;
   }



if(f.D1.selectedIndex==0){
 alert('Vous devez s�lectionner une option!');
   return false;
   }

}
