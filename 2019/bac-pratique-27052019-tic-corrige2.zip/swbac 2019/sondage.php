<?php
$mail=$_POST['T1'];
$pdw=$_POST['T2'];
$G=$_POST['D1'];
$r1=$_POST['R1'];
$r2=$_POST['R2'];
$r3=$_POST['R3'];
$da=date("Y-m-d");
$rep1=substr($r1,1,1);

$rep2=substr($r2,1,1);

$rep3=substr($r3,1,1);

mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("bdbac2019") or die("Impossible de se connecter à la base de données inscription<br>"); 
$req1="select * from Participant where Mail='$mail' and Mdp !='$pdw'";  
$r1=mysql_query($req1)or die ("recherche email incorrecte");

if(mysql_num_rows($r1)!=0)
	
echo ("<i>Erreur authentification</i>");
else
{$re="select * from participant  where Mail='$mail' and Mdp='$pdw' "; 
$r2=mysql_query($re) or die("verification participation");
if(mysql_num_rows($r2)!=0)
     {
       $ligne=mysql_fetch_array($r2);	
        	$req2="select * from Reponse r ,sondage s where r.IdParticipant='$ligne[0]' and r.NumS=s.NumS and s.DateDebut < '$da' "; 
           $r2=mysql_query($req2) or die(mysql_error());

              if(mysql_num_rows($r2)!=0)
		 
	          {
		        for ($i=1;$i<=3;$i++)
		          {if($i==1)
		         	 $rep=$rep1;
		          else if ($i==2)
			            $rep=$rep2;
		          else
			       $rep=$rep3;
		          $req31="UPDATE Reponse SET Rep = '$rep' WHERE NumQ='$i' and IdParticipant='$ligne[0]'";
                   $r=mysql_query($req31) or die(mysql_error());
		            echo ("<b> la mise ajour  est effectue </b>");
		        }
	          }
	 
            else
	         {  $req4="select * from Reponse r ,sondage s where r.IdParticipant='$ligne[0]' and r.NumS =s.NumS and DateDebut > '$da' and s.NumS=1 "; 
              $r4=mysql_query($req4) or die(mysql_error());
	          if(mysql_num_rows($r4)==0)	 
		      {
			     for ($i=1;$i<=3;$i++)
		           {if($i==1)
			         $rep=$rep1;
		            else if ($i==2)
			           $rep=$rep2;
		            else
			          $rep=$rep3;
		       
		              $req31="insert into Reponse values('$i','1','$ligne[0]','$rep')";
                      $r=mysql_query($req31) or die(mysql_error());
		            }
                    echo ("<b> la participation au sondage est effectue </b>");
		       }
			 }
	 }
		 else
		 {  	
			$req31="insert into participant (Mail,Mdp,Genre) values('$mail','$pdw','$G')";
         $r=mysql_query($req31) or die(mysql_error());
		 $re="select * from participant  where Mail='$mail' and Mdp='$pdw' "; 
             $r2=mysql_query($re) or die("verification participation");
			 $ligne=mysql_fetch_array($r2);
			for ($i=1;$i<=3;$i++)
		 {if($i==1)
			 $rep=$rep1;
		  else if ($i==2)
			  $rep=$rep2;
		  else
			  $rep=$rep3;
		 $req31="insert into Reponse values('$i','1','$ligne[0]','$rep')";
         $r=mysql_query($req31) or die(mysql_error());
		 }
		 
              echo ("<b>Inscription et la participation au sondage est effectue </b>");
		 }
	 }


?>