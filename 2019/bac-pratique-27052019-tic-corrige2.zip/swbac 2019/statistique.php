<?php

$th=$_POST['D1'];

$da=date("Y-m-d");
mysql_connect("localhost","root","") or die (mysql_error());
mysql_select_db("bdbac2019") or die("Impossible de se connecter à la base de données inscription<br>"); 
$req1="select * from sondage  where Theme='$th' and DateDebut <'$da' ";  
$r1=mysql_query($req1)or die (mysql_error());

if(mysql_num_rows($r1)==0)
	
echo ("<i>sondage non encore lance!</i>");
else
{$req2="select * from Reponse r ,sondage s where s.Theme='$th' and r.NumS=s.NumS"; 
   $r2=mysql_query($req2) or die("verification participation");
if(mysql_num_rows($r2)==0)
	
echo ("<i>aucune participation  enregistre a ce moment!</i>");
  else
     {	
        	$req2="select  count(distinct r.IdParticipant) from Reponse r ,sondage s where s.Theme='$th' and r.NumS=s.NumS  "; 
           $r2=mysql_query($req2) or die(mysql_error());
            $req3="select  count(distinct r.IdParticipant) from  participant p ,Reponse r ,sondage s  where p.Genre='F' and s.Theme='$th' and r.NumS=s.NumS and p.IdParticipant=r.IdParticipant   "; 
           $r3=mysql_query($req3) or die(mysql_error());
		     $req4="select  count(distinct r.IdParticipant) from  participant p ,Reponse r ,sondage s  where p.Genre='M' and s.Theme='$th' and r.NumS=s.NumS and p.IdParticipant=r.IdParticipant   "; 
           $r4=mysql_query($req4) or die(mysql_error());
           			 $ligne1=mysql_fetch_array($r2);
					  $ligne2=mysql_fetch_array($r3);
					  $ligne3=mysql_fetch_array($r4);
			  echo ("<center><b>Statistiques du sondage</b></center><br>");
			  echo("<b>Nombre total des participants au sondage </b>: ".$ligne1[0]." <br> ");
			  echo("<b>Nombre des femmes :</b>: ".$ligne2[0]." <br>");
			  echo("<b>Nombre des hommes :</b>: ".$ligne3[0]." <br>");
			  $req5="select q.NumQ ,q.Contenu  from question q,sondage s where s.Theme='$th' and s.NumS=q.NumS  "; 
           $r5=mysql_query($req5) or die(mysql_error());
		   echo("<table border='5'><tr><td colspan='2'></td><td colspan='3'>pourcentage</td></tr>");
		   echo("<tr><td>Numero </td><td>question </td><td>oui </td><td>non </td><td>Sans avis </td></tr>");
		   while($ligne5=mysql_fetch_array($r5))
		   {   
			   $req61="select count(*)  from reponse where NumQ='$ligne5[0]' and Rep ='O'  "; 
           $r61=mysql_query($req61) or die(mysql_error());
		   $req62="select count(*)  from reponse where NumQ='$ligne5[0]' and Rep ='N'  "; 
           $r62=mysql_query($req62) or die(mysql_error());
		    $req63="select count(*)  from reponse where NumQ='$ligne5[0]' and Rep ='S'  "; 
           $r63=mysql_query($req63) or die(mysql_error());
		    $ligne61=mysql_fetch_array($r61);
					  $ligne62=mysql_fetch_array($r62);
					  $ligne63=mysql_fetch_array($r63);
		   echo("<tr><td>".$ligne5[0]."</td><td>".$ligne5[1]."</td><td>".($ligne61[0]/$ligne1[0])*100 ."</td><td>".($ligne62[0]/$ligne1[0])*100 ."</td><td>".($ligne63[0]/$ligne1[0])*100 ."</td></tr>");
		   }
			   
		   
			  
		 }
	 }


?>