function alpha(ch)
{      chres="AZERTYUIOPQSDFGHJKLMNBVCXW0123456789";
ch=ch.toUpperCase();  
    for(i=0;i<ch.length;i++)  
          {   if(chres.indexOf(ch.charAt(i))==-1)
              return false; 
           }   
 return true;    
 }
function chaine(ch)
{    ch=ch.toUpperCase();    
for(i=0;i<ch.length;i++)
          {    if ((ch.charAt(i)<'A') ||(ch.charAt(i)>'Z'))
          
                        return false;  
          }
 return true;    
 }
 function compte(ch)
 {nbmaj=0;nbm=0;nbc=0;
  for(i=0;i<ch.length;i++)
          {    if ((ch.charAt(i)> 'A' )&&(ch.charAt(i)< 'Z' ))
                         nbmaj=nbmaj+1;
               if ((ch.charAt(i)> 'a' )&&(ch.charAt(i)< 'z' ))
                         nbm=nbm+1;
               if ((ch.charAt(i)> '0' )&&(ch.charAt(i)< '9' ))
                         nbc=nbc+1;           
          }
          
          if ((nbmaj==0)||(nbm==0)||(nbc==0))
          return false ;
          else
           return true;    
 }
function verif()
{var email=document.f1.T1.value;
var motpasse=document.f1.T2.value;
var gener =document.f1.D1.options.selectedIndex;
var g1=document.f1.R1[0].checked;
var g2=document.f1.R1[1].checked;
var g3=document.f1.R1[2].checked;
var g4=document.f1.R2[0].checked;
var g5=document.f1.R2[1].checked;
var g6=document.f1.R2[2].checked;
var g7=document.f1.R3[0].checked;
var g8=document.f1.R3[1].checked;
var g9=document.f1.R3[2].checked;

ch1=email.substr(0,email.indexOf('@'));
ch2=email.substr(ch1.length+1,email.indexOf('.')-ch1.length-1);
ch3=email.substr(email.indexOf('.')+1,email.length-((ch1.length+ch2.length)+2));
 if((email.indexOf('@')==-1)||(email.indexOf('.')==-1))
{alert("l'email doit etre sous la forme ch1@ch2.ch3");return false;}
else if((alpha(ch1)==false )||(alpha(ch2)==false)||(chaine(ch3)==false))
{alert("verfier ch1 , ch 2 et ch3 de votre email ");return false;}
else if((ch1.length <3 )||(ch2.length <3)||((ch3.length<2)||(ch3.length>4)))
{alert("verfier votre email");return false;}
else if((motpasse.length !=6)||(compte(motpasse) ==false ))
{alert("verifier mot de passe");return false;}
else if((gener ==-1)||(gener ==0 ))
{alert("selectionner votre gnere");return false;}
else if(((g1==false)&&(g2==false)&&(g3==false))||((g4==false)&&(g5==false)&&(g6==false))||((g7==false)&&(g8==false)&&(g9==false)))
{alert("il faut selectionner une reponse");return false;}
else
{alert("le formulaire est valide");return true;}

}


