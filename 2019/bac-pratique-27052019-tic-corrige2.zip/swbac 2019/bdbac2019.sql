-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le : Mar 28 Mai 2019 à 02:28
-- Version du serveur: 5.5.20
-- Version de PHP: 5.3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bdbac2019`
--

-- --------------------------------------------------------

--
-- Structure de la table `participant`
--

CREATE TABLE IF NOT EXISTS `participant` (
  `IdParticipant` int(4) NOT NULL AUTO_INCREMENT,
  `Mail` varchar(50) NOT NULL,
  `Mdp` varchar(6) NOT NULL,
  `Genre` char(1) NOT NULL,
  PRIMARY KEY (`IdParticipant`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `participant`
--

INSERT INTO `participant` (`IdParticipant`, `Mail`, `Mdp`, `Genre`) VALUES
(1, 'ggg@hhh.kkk', 'kkMM23', 'M'),
(2, 'aaa@rrr.jj', 'BBBf23', 'F'),
(9, 'nomene@hhh.kkk', 'hhMl52', 'M'),
(10, 'amal@hhh.kkk', 'kll3M1', 'F'),
(11, 'bbb@jjj.ll', 'mmL562', 'M');

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `NumQ` int(4) NOT NULL,
  `NumS` int(4) NOT NULL,
  `Contenu` varchar(150) NOT NULL,
  PRIMARY KEY (`NumQ`,`NumS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `question`
--

INSERT INTO `question` (`NumQ`, `NumS`, `Contenu`) VALUES
(1, 1, 'les informations partages sur les reseaux'),
(2, 1, 'l''usage des reseaux sociaux par les enfants doit etre sous le controle parentale'),
(3, 1, 'les reseauxsociaux deviennent une necessite pour les citoyens');

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE IF NOT EXISTS `reponse` (
  `NumQ` int(11) NOT NULL,
  `NumS` int(11) NOT NULL,
  `IdParticipant` int(11) NOT NULL,
  `Rep` char(1) NOT NULL,
  PRIMARY KEY (`NumQ`,`NumS`,`IdParticipant`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reponse`
--

INSERT INTO `reponse` (`NumQ`, `NumS`, `IdParticipant`, `Rep`) VALUES
(1, 1, 1, 'O'),
(1, 1, 9, 'O'),
(1, 1, 10, 'N'),
(1, 1, 11, 'N'),
(2, 1, 1, 'O'),
(2, 1, 9, 'O'),
(2, 1, 10, 'O'),
(2, 1, 11, 'S'),
(3, 1, 1, 'O'),
(3, 1, 9, 'O'),
(3, 1, 10, 'N'),
(3, 1, 11, 'S');

-- --------------------------------------------------------

--
-- Structure de la table `sondage`
--

CREATE TABLE IF NOT EXISTS `sondage` (
  `NumS` int(4) NOT NULL,
  `Theme` varchar(50) NOT NULL,
  `DateDebut` date NOT NULL,
  PRIMARY KEY (`NumS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sondage`
--

INSERT INTO `sondage` (`NumS`, `Theme`, `DateDebut`) VALUES
(1, 'les reseaux sociaux', '2019-05-01'),
(2, 'les jeux video', '2019-06-01');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
