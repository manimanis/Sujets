﻿function alphanumerique(ch)
   {
		ch=ch.toUpperCase();
		i=0;
		verife=true;
		do
		  {
			if (     ((ch.charAt(i)>="A")&& (ch.charAt(i)<="Z")) ||  ((ch.charAt(i)>="0")&& (ch.charAt(i)<="9"))      )
			   {i++;}
			else
			   { verife=false;}
		  }
		while (   (verife) && (i<ch.length)   );
		return verife;
	}


function alphabetique(ch)
   {
		ch=ch.toUpperCase();
		i=0;
		verife=true;
		do
		  {
			if (     (ch.charAt(i)>="A")&& (ch.charAt(i)<="Z")      )
			   {i++;}
			else
			   { verife=false;}
		  }
		while (   (verife) && (i<ch.length)   );
		return verife;
	}


/* -----------------------------------------------------------------------------------------*/
/* --------------Déclaration de la Fonction Principale  test ()   --------------------------*/
/* -----------------------------------------------------------------------------------------*/
function test(){
 /* -----------Contrôle sur le champ Mail ------------------ */
mail=f.T1.value; 
if (     (mail.length>50) || (mail.indexOf("@")==-1) || (mail.indexOf(".")==-1)	||  ((mail.indexOf("."))< (mail.indexOf("@")))    )
      { alert("Mail \n |-----> Invalide : Le Mail doit  vérifier ces contraintes: <-----| \n---> longueur <=50\n---> Arobase (@) existe\n---> Le point (.) existe\n---> La position du point (.) > La position du arobase(@)\n|<-------------------------------------------------------------->|");
	    return false;}
else
      {
     		ch1=mail.substr(0,mail.indexOf("@"));
            if (  (! alphanumerique(ch1)) || (ch1.length<3)  )
				 { alert("Mail \n |-----> Invalide : Le Mail doit  vérifier ces contraintes: <-----| \n---> La partie ch1 de Mail doit être Alphanumérique\n---> La longueur de ch1 de Mail doit être >=3 \n|<-------------------------------------------------------------->|");
				   return false;}
			else
			    {
				   ch2=mail.substring(mail.indexOf("@")+1, mail.indexOf("."));
				   if (  (! alphanumerique(ch2)) || (ch2.length<3)  )
				        { alert("Mail \n |-----> Invalide : Le Mail doit  vérifier ces contraintes: <-----| \n---> La partie ch2 de Mail doit être Alphanumérique\n---> La longueur de ch2 de Mail doit être >=3 \n|<-------------------------------------------------------------->|");
						  return false;}
					else
					    { 
					      ch3=mail.substr(mail.indexOf(".")+1);
						  if (  (! alphabetique(ch3)) || (ch3.length<2) || (ch3.length>4)  )
				               { alert("Mail \n |-----> Invalide : Le Mail doit  vérifier ces contraintes: <-----| \n---> La partie ch3 de Mail doit être Alphabétique\n---> La longueur de ch3 de Mail doit être dans [2..4] \n|<-------------------------------------------------------------->|");
							     return false;}
				    	}
		       	}
	  }
  /* ------------------------------------------------------- */

 /* -----------Contrôle sur le champ mot de passe ------------------ */
mdp=f.T2.value;
if (mdp.length!=6)
 {alert("Mot de Passe \n |-----> Invalide : Le Mot de passe doit  vérifier ces contraintes: <-----| \n---> Une chaine de 6 caractères\n|<-------------------------------------------------------------->|");
   return false;}	
else
 {
	nb_minus=0; nb_chif=0; nb_majus=0;
	for(i=0;i<6;i++)
	   {
		    if (   (mdp.charAt(i)>="A") &&  (mdp.charAt(i)<="Z")    )
		     { nb_majus++; }
		    if (   (mdp.charAt(i)>="a") &&  (mdp.charAt(i)<="z")    )
		     { nb_minus++; }
		    if (   (mdp.charAt(i)>="0") &&  (mdp.charAt(i)<="9")    )
		     { nb_chif++; }
	   }
	if (   (nb_chif==0) ||  (nb_minus==0)  ||  (nb_majus==0)    )
	  {alert("Mot de Passe \n |-----> Invalide : Le Mot de passe doit  vérifier ces contraintes: <-----| \n ---> comporte au moins une lettre majuscule, une lettre minuscule et un chiffre\n|<-------------------------------------------------------------->|");
		return false;}
 }
  /* ------------------------------------------------------- */

 /* -----------Contrôle sur la liste déroulante Genre ------------------ */
if (f.D1.selectedIndex==0)
{alert("Genre \n |-----> Invalide : Le Genre doit être sélectionner !!: <-----| \n|<---------------------------------------------------------->|");
 return false;}
   /* ------------------------------------------------------- */

 /* -----------Contrôle sur les boutons radio (Questions du Sondage) ------------------ */
if (     (f.R1[0].checked==false) && (f.R1[1].checked==false) && (f.R1[2].checked==false)   )
  {	alert("Réponse à la Question n°1 \n |-----> Invalide : une réponse doit être sélectionner !!: <-----| \n|<---------------------------------------------------------->|");
	return false;}
  
if (     (f.R2[0].checked==false) && (f.R2[1].checked==false) && (f.R2[2].checked==false)   )
  {	alert("Réponse à la Question n°2 \n |-----> Invalide : une réponse doit être sélectionner !!: <-----| \n|<---------------------------------------------------------->|");
	return false;}
  
if (     (f.R3[0].checked==false) && (f.R3[1].checked==false) && (f.R3[2].checked==false)   )
  {	alert("Réponse à la Question n°3 \n |-----> Invalide : une réponse doit être sélectionner !!: <-----| \n|<---------------------------------------------------------->|");
	return false;}
     /* ------------------------------------------------------- */
}

/* --------------------------------------------------------------------------------------------------------------------------------------------*/



/* -----------Fonction de la page statistiques.HTML -----------------------------*/
/*  Remarque: On affecte les clés primaires des sondages dans les valeurs de la liste déroulante |---->(Voir propriétés de la liste déroulante) */
function choix_theme() {
if (f1.D1.selectedIndex==0)
{alert(" Genre  \n |-----> Invalide : Le Genre doit être sélectionner !!: <-----| \n|<----------------------------------------------------------->|");
 return false;}	
}