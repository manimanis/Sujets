<?php

mysql_connect("localhost","root","") or die ("Connexion au serveur échoué !!!!");
mysql_select_db("BD2019") or die ("Selection de la Base non établie !!!!");


$sondage=$_POST['D1'];
$date=date("Y-m-d");

$req=mysql_query("
                  SELECT *
				  FROM Sondage
				  WHERE DateDebut> '$date' and NumS='$sondage'
				 ");
if (mysql_num_rows($req)!=0)
    {
	    echo ("<b><i>Sondage non encore lancé !</b></i>");
    }
else
    {
		$req=mysql_query("
		                  SELECT *
						  FROM reponse
						  WHERE NumS='$sondage'
						 ");
		if (mysql_num_rows($req)==0)
		   {
			   echo ("<b><i>Aucune Participation enregistrée à ce moment !</b></i>");			   
		   }
		else
		   {
			    
				$req=mysql_query("
			                                   SELECT count( DISTINCT idparticipant)
								               FROM reponse
								               WHERE NumS='$sondage'
								             ");
				$ligne=mysql_fetch_row($req);
				$total_participant=$ligne[0];
				
				
				
				
				$req=mysql_query("
			                             SELECT count( DISTINCT  p.idparticipant)
								         FROM reponse r, participant p
								         WHERE r.idparticipant=p.idparticipant and NumS='$sondage' and genre='F'
								        ");
				$ligne=mysql_fetch_row($req);
				$nb_femmes=$ligne[0];
				
				
				
				
				$req=mysql_query("
			                             SELECT count( DISTINCT  p.idparticipant)
								         FROM reponse r, participant p
								         WHERE r.idparticipant=p.idparticipant and NumS='$sondage' and genre='M'
								        ");	
                $ligne=mysql_fetch_row($req);
				$nb_hommes=$ligne[0];
				
				
				
				
				
				
			    echo ('<p align="center"><font face="Bauhaus 93" size="7" color="#800080">Statistiques du Sondage</font></p>
                      <p><font face="Berlin Sans FB Demi" size="5" color="#800000">Nombre Total des participants au Sondage :'.$total_participant.'</font></p>
					  <p><font face="Berlin Sans FB Demi" size="5" color="#FF00FF">Nombre des femmes :'.$nb_femmes.'</font></p>
					  <p><font face="Berlin Sans FB Demi" size="5" color="#000080">Nombre des hommes :'.$nb_hommes.'</font></p>');
					
				echo('	<table border="1" width="100%" id="table1">
							 <tr>
								<td colspan="2" bordercolorlight="#FFFFFF" bordercolordark="#FFFFFF">&nbsp;</td>
								<td colspan="3" align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#800000">Pourcentages</font></td>
							 </tr>
			
							<tr>
								<td align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#008080">N°</font></td>
								<td align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#008080">Question</font></td>
								<td align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#008080">&quot;Oui&quot;</font></td>
								<td align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#008080">&quot;Non&quot;</font></td>
								<td align="center">
								<font face="Berlin Sans FB Demi" size="5" color="#008080">&quot;Sans Avis&quot;</font></td>
							</tr>');
				
                $req=mysql_query("
                                 select q.NumQ, contenu
                                 from reponse r, question q
                                 where 	r.numq=q.numq and r.nums='$sondage'
                                 group by numq
                                 order by numq
                                 ");
                while ($ligne=mysql_fetch_row($req))
				   {
					
					$rep_Oui=strval($ligne[0]).'O';
					$rep_Non=strval($ligne[0]).'N';
					$rep_SansAvis=strval($ligne[0]).'S';
					
					$req2=mysql_query("
					                   select count(rep)
									   from reponse
									   where nums='$sondage' and rep='$rep_Oui'
									  ");
					$row=mysql_fetch_row($req2);
					$pourcentage_Oui=($row[0]/$total_participant)*100;
					
					
					$req2=mysql_query("
					                   select count(rep)
									   from reponse
									   where nums='$sondage' and rep='$rep_Non'
									  ");
					$row=mysql_fetch_row($req2);
					$pourcentage_Non=($row[0]/$total_participant)*100;
					
					
					$req2=mysql_query("
					                   select count(rep)
									   from reponse
									   where nums='$sondage' and rep='$rep_SansAvis'
									  ");
					$row=mysql_fetch_row($req2);
					$pourcentage_SansAvis=($row[0]/$total_participant)*100;
					
				    

					echo('			<tr>
								<td>'.$ligne[0].'</td>
								<td>'.$ligne[1].'</td>
								<td>'.round($pourcentage_Oui).'    %</td>
								<td>'.round($pourcentage_Non).'    %</td>
								<td>'.round($pourcentage_SansAvis).'    %</td>
							</tr>
				    ');
				}
				echo('</table>');

		   }
			 
		                 
	}
mysql_close();

?>