﻿<?php
mysql_connect("localhost","root","") or die ("Connexion au serveur échoué !!!!");
mysql_select_db("BD2019") or die ("Selection de la Base non établie !!!!");

$mail=$_POST['T1'];
$mdp=$_POST['T2'];

$genre=$_POST['D1'];

$R1=$_POST['R1'];
$R2=$_POST['R2'];
$R3=$_POST['R3'];


$req1=mysql_query("
                   Select *
				   from participant
				   where  mail='$mail'
				 ");
if ( mysql_num_rows($req1)!=0)
  {
	$req2=mysql_query("
	                   select *
					   from participant
					   where mail='$mail' and mdp='$mdp'
					 ");
	if (mysql_num_rows($req2)==0)
	    {
			echo ("Erreur d'authentification  !!!");
		}
	else
	    {
			$ligne=mysql_fetch_row($req2);
			$participant=$ligne[0];
			$req3=mysql_query("
			                   select *
							   from reponse
							   where (idparticipant='$participant') and (NumS=1) and  (NumQ in (1,2,3))
							 ");
			if (mysql_num_rows($req3)==3)
	             {
			       $req4=mysql_query(" Update reponse set rep='$R1'   where (idparticipant='$participant') and  (NumS=1) and (NumQ=1) ");
				   $req5=mysql_query(" Update reponse set rep='$R2'   where (idparticipant='$participant') and  (NumS=1) and (NumQ=2) ");
                   $req6=mysql_query(" Update reponse set rep='$R3'   where (idparticipant='$participant') and  (NumS=1) and (NumQ=3) ");  
                   if (mysql_affected_rows()!=-1)
				      {
						echo ("Mise à jour effectuée avec succès");  
					  }
                   else
				      {
						echo ("Mise à jour non effectuée !!!! problème de mise à jour ");  
					  }					   
		         }
			else
			   {
				   $req4=mysql_query("
				                      Select *
									  from participant
									  where idparticipant='$participant'
									");
					if (mysql_num_rows($req4)!=0)
	                    {
							$req5=mysql_query("
							                  insert into  reponse  values (1,1,'$participant','$R1'), (2,1,'$participant','$R2'),(3,1,'$participant','$R3')
											  ");
							if (mysql_affected_rows() !=-1)
							   {
			                     echo ("Participation au sondage effectuée avec succès");
							   }
							else
				               {
						          echo ("Insertion non effectuée !!!! problème d'insertion ");  
					           }	 
		                }
				    
			   }
		}
  }
  else
	{
		$req5=mysql_query("
		                    insert into participant (mail,mdp,genre)  values ('$mail','$mdp','$genre')
		    			 ");
		$req=mysql_query("
		                  select idparticipant
						  from participant
		    			  where  mail='$mail' and mdp='$mdp'
			    		 ");
		$ligne=mysql_fetch_row($req);
		$new_participant=$ligne[0];
		$req6=mysql_query("
		                   insert into  reponse  values (1,1,'$new_participant','$R1'), (2,1,'$new_participant','$R2'),(3,1,'$new_participant','$R3')
						  ");
		if (mysql_affected_rows() !=0)
		   {
		        echo ("Inscription et participation au sondage effectuées avec succès");
		   }
		else
		    {
		       echo (" Inscription et participation au sondage  NON EFFECTUEES!!!!
            			  soit le problème au niveau de l'ajout de participant 
						  ou bien
					  au niveau de l'insertion des réponses");  
		    }	

	}

mysql_close();
?>