function alpha(ch)
{
ch=ch.toUpperCase();
i=0;
while((ch.charAt(i)>='A' && ch.charAt(i)<='Z') || (ch.charAt(i)>='0' && ch.charAt(i)<='9')) i++;
return i==ch.length;
}

function test()
{
mail=f.T1.value;
p=mail.indexOf('@');
pp=mail.indexOf('.');
ch1=mail.substr(0,p);
ch2=mail.substr(p+1,pp-p-1);
ch3=mail.substr(pp+1);
if (p==-1 || pp==-1 || pp<p || !alpha(ch1) || !alpha(ch2) || ch1.length<3 || ch2.length<3 || ch3.length<2 || ch3.length>3)
{alert(" Verifier votre @mail");return false;}
mp=f.T2.value;
nbmaj=0;
nbmin=0;
nbch=0;
for (i=0;i<mp.length;i++)
if (mp.charAt(i)>='A' && mp.charAt(i)<='Z') nbmaj++;
else if (mp.charAt(i)>='a' && mp.charAt(i)<='z') nbmin++;
else nbch++;
if (nbmaj==0 || nbmin==0 || nbch==0 || mp.length!=6)
{alert("Verifier votre mot de passe");return false;}
if (f.D1.selectedIndex<1) {alert("choisir une genre");return false;}
if (!f.R1[0].checked && !f.R1[1].checked && !f.R1[2].checked){alert("r�pondre � la question N� 1");return false;}
if (!f.R2[0].checked && !f.R2[1].checked && !f.R2[2].checked){alert("r�pondre � la question N� 2");return false;}
if (!f.R3[0].checked && !f.R3[1].checked && !f.R3[2].checked){alert("r�pondre � la question N� 3");return false;}
}
function verif()
{
if (f.D1.selectedIndex<1){alert("choisir un th�me ");return false;}
}