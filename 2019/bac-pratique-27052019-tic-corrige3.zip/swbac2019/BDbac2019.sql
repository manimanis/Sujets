-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Serveur: 127.0.0.1
-- Généré le : Lun 27 Mai 2019 à 16:36
-- Version du serveur: 5.5.10
-- Version de PHP: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `BDbac2019`
--

-- --------------------------------------------------------

--
-- Structure de la table `participant`
--

CREATE TABLE IF NOT EXISTS `participant` (
  `IdParticipant` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(50) NOT NULL,
  `Mdp` varchar(6) NOT NULL,
  `Genre` varchar(1) NOT NULL,
  PRIMARY KEY (`IdParticipant`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `participant`
--


-- --------------------------------------------------------

--
-- Structure de la table `qeustion`
--

CREATE TABLE IF NOT EXISTS `qeustion` (
  `NumQ` int(11) NOT NULL,
  `NumS` int(11) NOT NULL,
  `Contenu` varchar(150) NOT NULL,
  PRIMARY KEY (`NumQ`,`NumS`),
  KEY `NumS` (`NumS`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `qeustion`
--

INSERT INTO `qeustion` (`NumQ`, `NumS`, `Contenu`) VALUES
(1, 1, 'les informations partagées sur les réseaux sociaux sont fiables'),
(1, 2, 'les jeux vidéo contribuent au développement de la pensée logique'),
(2, 1, 'l''usage des réseaux sociaux par les enfants doit être sous le contrôle parental'),
(3, 1, 'les réseaux sociaux deviennent une nécessité pour les citoyens');

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

CREATE TABLE IF NOT EXISTS `reponse` (
  `NumQ` int(11) NOT NULL,
  `NumS` int(11) NOT NULL,
  `Idparticipant` int(11) NOT NULL,
  `rep` varchar(1) NOT NULL,
  PRIMARY KEY (`NumQ`,`NumS`,`Idparticipant`),
  KEY `NumS` (`NumS`),
  KEY `Idparticipant` (`Idparticipant`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `reponse`
--


-- --------------------------------------------------------

--
-- Structure de la table `sondage`
--

CREATE TABLE IF NOT EXISTS `sondage` (
  `NumS` int(11) NOT NULL AUTO_INCREMENT,
  `Theme` varchar(50) NOT NULL,
  `DateDebut` date NOT NULL,
  PRIMARY KEY (`NumS`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `sondage`
--

INSERT INTO `sondage` (`NumS`, `Theme`, `DateDebut`) VALUES
(1, 'les réseaux sociaux', '2019-05-01'),
(2, 'les jeux vidéo', '2019-06-01');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `qeustion`
--
ALTER TABLE `qeustion`
  ADD CONSTRAINT `qeustion_ibfk_1` FOREIGN KEY (`NumS`) REFERENCES `sondage` (`NumS`);

--
-- Contraintes pour la table `reponse`
--
ALTER TABLE `reponse`
  ADD CONSTRAINT `reponse_ibfk_3` FOREIGN KEY (`Idparticipant`) REFERENCES `participant` (`IdParticipant`),
  ADD CONSTRAINT `reponse_ibfk_1` FOREIGN KEY (`NumQ`) REFERENCES `qeustion` (`NumQ`),
  ADD CONSTRAINT `reponse_ibfk_2` FOREIGN KEY (`NumS`) REFERENCES `sondage` (`NumS`);
