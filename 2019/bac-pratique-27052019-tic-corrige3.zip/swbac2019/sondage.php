<?php 
mysql_connect("localhost","root","");
mysql_select_db("BDbac2019");
$mail=$_POST["T1"];
$mp=$_POST["T2"];
$genre=$_POST["D1"];
$q1=$_POST["R1"];
$q2=$_POST["R2"];
$q3=$_POST["R3"];
$req="select IdParticipant from participant where mail='$mail' and mdp!='$mp'";
$res=mysql_query($req);
$t=mysql_fetch_array($res);
if (mysql_num_rows($res)!=0)
	echo "Erreur d'authetification";
else
{
$req1="select IdParticipant from participant where mail='$mail' and mdp='$mp'";
$res1=mysql_query($req1);
if (mysql_num_rows($res1)!=0)
{
$t=mysql_fetch_array($res1);
$req2="select * from reponse where Nums='1' and IdParticipant='$t[0]'";
$res2=mysql_query($req2);
if (mysql_num_rows($res2)!=0)
{
	mysql_query("update reponse set rep='$q1[1]' where nums='1' and numq='1' and IdParticipant='$t[0]'");
	mysql_query("update reponse set rep='$q2[1]' where nums='1' and numq='2' and IdParticipant='$t[0]'");
	mysql_query("update reponse set rep='$q3[1]' where nums='1' and numq='3' and IdParticipant='$t[0]'");
	echo "Mise a jour effectuee avec succes";
}
else
{
	mysql_query("insert into reponse values ('1','1','$t[0]','$q1[1]')");
	mysql_query("insert into reponse values ('2','1','$t[0]','$q2[1]')");
	mysql_query("insert into reponse values ('3','1','$t[0]','$q3[1]')");
	
	echo "participation au sondage effectuee avec succes";	
}
}
else
{   
    mysql_query("insert into participant values ('','$mail','$mp','$genre')");
    $res1=mysql_query($req1);$t=mysql_fetch_array($res1);
	mysql_query("insert into reponse values ('1','1','$t[0]','$q1[1]')");
	mysql_query("insert into reponse values ('2','1','$t[0]','$q2[1]')");
	mysql_query("insert into reponse values ('3','1','$t[0]','$q3[1]')");
	echo "inscription et participation au sondage effectuee avec succes";	
}
}
?>
	