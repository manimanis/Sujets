<?php 
mysql_connect("localhost","root","");
mysql_select_db("BDbac2019");
$d=$_POST["D1"];
$date=date("Y-m-d");
$req="select * from sondage where nums='$d' and datedebut<'$date'";
$res=mysql_query($req);
$req1="select * from reponse where nums='$d'";
$res1=mysql_query($req1);
if (mysql_num_rows($res)==0)
	echo "sondage non encore lance!";
else if(mysql_num_rows($res1)==0)
	echo "Aucune participation enregistree à ce moment";
else
{
$req="select distinct(idparticipant) from reponse where nums='$d'";
$res=mysql_query($req);
$req1="select distinct(r.idparticipant) from reponse r,participant p where r.idparticipant=p.idparticipant and nums='$d' and p.genre='F'";
$res1=mysql_query($req1);
$req2="select distinct(r.idparticipant) from reponse r,participant p where r.idparticipant=p.idparticipant and nums='$d' and p.genre='M'";
$res2=mysql_query($req2);
echo "Nombre total des participant au sondage :".mysql_num_rows($res)."<br>";	
echo "Nombre des femmes :".mysql_num_rows($res1)."<br>";
echo "Nombre des hommes :".mysql_num_rows($res2)."<br>";
echo"<table border='1' style='border-left-width: 0px; border-top-width: 0px'>";
echo"<tr><td style='border-left-style: none; border-left-width: medium; border-right-style: none; border-right-width: medium; border-top-style: none; border-top-width: medium'>&nbsp;</td>";
echo"<td style='border-left-style: none; border-left-width: medium; border-top-style: none; border-top-width: medium'>&nbsp;</td>";
echo"<td colspan='3'><p align='center'>Pourcentage </td>";
echo"</tr><tr><td>N</td><td>Question</td><td>Oui</td><td>Non</td><td>Sans avis</td></tr>";

for($i=1;$i<=3;$i++)
{
$req4="select  contenu from question where numq='$i'";
$res4=mysql_query($req4);$t=mysql_fetch_array($res4);
$res5=mysql_query("select * from reponse where numq='$i' and nums='$d' and rep='O'");
$res6=mysql_query("select * from reponse where numq='$i' and nums='$d' and rep='N'");
$res7=mysql_query("select * from reponse where numq='$i' and nums='$d' and rep='S'");
$res8=mysql_query("select * from reponse where numq='$i' and nums='$d'");
echo("<tr><td>$i</td><td>$t[0]</td><td align='center'>".number_format((mysql_num_rows($res5)/mysql_num_rows($res8)*100),2,',',' ')."%</td><td align='center'>".number_format((mysql_num_rows($res6)/mysql_num_rows($res8)*100),2,',',' ')."%</td><td align='center'>".number_format((mysql_num_rows($res7)/mysql_num_rows($res8)*100),2,',',' ')."%</td></tr>");	

}
}

?>