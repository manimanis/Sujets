<?php
//recuperation des informations du formulaire
$station=$_POST['D1'];
$Saison=$_POST['D2'];
$annee=$_POST['R1'];
$temp=trim($_POST['T1']);
$pluie=trim($_POST['T2']);
//connection au serveur et a la base
$idc=mysql_connect("127.0.0.1","root","");
$c=mysql_select_db("bdbac2021");
if($annee=='V1')
$a='2018';
else
$a='2019';
//recuperation id station
$requete1="select * from Station where Nom='$station'";
$resultat1=mysql_query($requete1);
$IdStation=mysql_fetch_array($resultat1);
//selectionner les information de mesure
$requete="select * from mesure where IdStation='$IdStation[0]' and Saison='$Saison' and annee='$a'";
$resultat=mysql_query($requete);

if (mysql_num_rows($resultat)!=0)
{
	echo("mesures deja enregistrees !");
}else
{
	$resultat3=mysql_query("insert into mesure values ('$IdStation[0]','$a','$Saison','$temp','$pluie')");
	if (mysql_affected_rows()){
	echo("Ajout effectue avec succes");}
}
?>