<?php
//recuperation des information du formulaire
$station=$_POST['D1'];
$s=$_POST['R1'];
//connection au serveur et a la base
$idc=mysql_connect("127.0.0.1","root","");
$c=mysql_select_db("bdbac2021");
//recuperation id station
$requete1="select * from Station where Nom='$station'";
$resultat1=mysql_query($requete1);
$IdStation=mysql_fetch_array($resultat1);
//selectionner les informations de mesure
$requete="select * from mesure where IdStation='$IdStation[0]'";
$resultat=mysql_query($requete);
echo mysql_num_rows($resultat);
?>

<TABLE border=1 align="center">
<TR>
<TD> Saison </TD>
<TD> Annee </TD>
<TD> Mesures </TD>
</TR>
<?php while($enreg=mysql_fetch_array($resultat))
{
?>
<TR>
<TD><?php echo $enreg["Saison"];?></TD>
<TD><?php echo $enreg["Annee"];?></TD>
<TD>
<?php 
if($s=='V1')
echo $enreg["Temperature"];
else
echo $enreg["Pluie"];
?></TD>

</TR>
<?php } ?>
</TABLE>
<?php
mysql_close ($idc) ;
?>