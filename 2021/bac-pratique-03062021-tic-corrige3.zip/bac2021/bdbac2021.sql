-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Serveur: 127.0.0.1
-- Généré le : Ven 04 Juin 2021 à 21:43
-- Version du serveur: 5.1.43
-- Version de PHP: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bdbac2021`
--

-- --------------------------------------------------------

--
-- Structure de la table `mesure`
--

CREATE TABLE IF NOT EXISTS `mesure` (
  `IdStation` int(11) NOT NULL,
  `Annee` int(11) NOT NULL,
  `Saison` varchar(9) NOT NULL,
  `Temperature` decimal(5,2) NOT NULL,
  `Pluie` int(11) NOT NULL,
  PRIMARY KEY (`IdStation`,`Annee`,`Saison`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `mesure`
--

INSERT INTO `mesure` (`IdStation`, `Annee`, `Saison`, `Temperature`, `Pluie`) VALUES
(60715, 2018, 'Eté', 30.60, 24),
(60715, 2018, 'Hiver', 13.50, 150),
(60715, 2019, 'Printemps', 25.60, 80),
(60731, 2018, 'Eté', 33.60, 10),
(60731, 2018, 'Hiver', 17.60, 100),
(60731, 2019, 'Automne', 30.00, 11),
(60780, 2019, 'Eté', 42.30, 0),
(60780, 2019, 'Hiver', 16.60, 10);

-- --------------------------------------------------------

--
-- Structure de la table `station`
--

CREATE TABLE IF NOT EXISTS `station` (
  `IdStation` int(11) NOT NULL,
  `Niom` varchar(30) NOT NULL,
  `Ville` varchar(30) NOT NULL,
  PRIMARY KEY (`IdStation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `station`
--

INSERT INTO `station` (`IdStation`, `Niom`, `Ville`) VALUES
(60715, 'Carthage', 'Tunis'),
(60731, 'Enfidha-Aéroport', 'Sousse'),
(60780, 'El-Borma', 'Tataouine');
