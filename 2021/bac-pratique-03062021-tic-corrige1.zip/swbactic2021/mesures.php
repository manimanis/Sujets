<meta charset="utf-8">
<?php
mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("bdtic2021") or die(mysql_error());
$idst=$_POST["D1"];
$sai=$_POST["D2"];
$ann=$_POST["R1"];
$tem=$_POST["T1"];
$pl=$_POST["T2"];
$req="select * from mesure where idstation='$idst' and annee='$ann' and saison='$sai'";
$rep=mysql_query($req)or die(mysql_error());
if(mysql_num_rows($rep)!=0)die("mesures déjà enregistrées !");
$req="insert into mesure values('$idst','$ann','$sai','$tem','$pl')";
$rep=mysql_query($req)or die(mysql_error());
if(mysql_affected_rows()!=-1)echo("ajout effectué avec succès");
mysql_close();
?>