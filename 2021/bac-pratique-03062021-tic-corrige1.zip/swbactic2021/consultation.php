<meta charset="utf-8">
<?php
mysql_connect("localhost","root") or die(mysql_error());
mysql_select_db("bdtic2021") or die(mysql_error());
$idst=$_POST["D1"];
$dc=$_POST["R1"];
$req="select nom from station  where idstation='$idst'";
$rep=mysql_query($req)or die(mysql_error());
$T=mysql_fetch_array($rep);
echo'<p align="center"><b>Station :</b>
		'.$T[0];
echo'<table border="1" width="100%">
	<tr>
		<td align="center"><b>Saison</b></td>
		<td align="center"><b>Année</b></td>
		<td align="center"><b>Mesure enregistrée</b></td>
	</tr>';
if($dc=="temperature"){
	$req="select saison,annee,temperature from station,mesure
       where mesure.idstation='$idst' 
	   and mesure.idstation=station.idstation";
$rep=mysql_query($req)or die(mysql_error());
while($T=mysql_fetch_array($rep)){	
	
	echo'<tr>
		<td align="center">'.$T[0].'</td>
		<td align="center">'.$T[1].'</td>
		<td align="center">'.$T[2].'</td>
	</tr>';
}
echo'</table>';}
else{
$req="select saison,annee,pluie from station,mesure
       where mesure.idstation='$idst' 
	   and mesure.idstation=station.idstation";
$rep=mysql_query($req)or die(mysql_error());
while($T=mysql_fetch_array($rep)){	
	
	echo'<tr>
		<td align="center">'.$T[0].'</td>
		<td align="center">'.$T[1].'</td>
		<td align="center">'.$T[2].'</td>
	</tr>';
}
echo'</table>';}


mysql_close();
?>