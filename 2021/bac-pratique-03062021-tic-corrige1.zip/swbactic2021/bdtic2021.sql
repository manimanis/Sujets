-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Vendredi 04 Juin 2021 à 08:28
-- Version du serveur: 5.0.27
-- Version de PHP: 5.2.0
-- 
-- Base de données: `bdtic2021`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `mesure`
-- 

CREATE TABLE `mesure` (
  `idstation` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `saison` varchar(9) NOT NULL,
  `temperature` decimal(5,2) NOT NULL,
  `pluie` int(11) NOT NULL,
  PRIMARY KEY  (`idstation`,`annee`,`saison`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `mesure`
-- 

INSERT INTO `mesure` (`idstation`, `annee`, `saison`, `temperature`, `pluie`) VALUES 
(60715, 2018, 'automne', 30.00, 555),
(60715, 2018, 'ete', 30.60, 24),
(60715, 2018, 'hiver', 13.50, 150),
(60715, 2018, 'printemps', 10.00, 500),
(60715, 2019, 'ete', 39.00, 300),
(60715, 2019, 'printemps', 25.60, 80),
(60731, 2018, 'ete', 33.60, 10),
(60731, 2018, 'hiver', 17.60, 100),
(60731, 2019, 'automne', 30.00, 11),
(60780, 2018, 'ete', 50.00, 600),
(60780, 2018, 'hiver', 49.00, 220),
(60780, 2019, 'ete', 42.30, 0),
(60780, 2019, 'hiver', 16.60, 10),
(60780, 2019, 'printemps', 22.00, 22);

-- --------------------------------------------------------

-- 
-- Structure de la table `station`
-- 

CREATE TABLE `station` (
  `idstation` int(11) NOT NULL,
  `nom` varchar(30) NOT NULL,
  `ville` varchar(30) NOT NULL,
  PRIMARY KEY  (`idstation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `station`
-- 

INSERT INTO `station` (`idstation`, `nom`, `ville`) VALUES 
(60715, 'carthage', 'tunis'),
(60731, 'enfidha-aeroport', 'sousse'),
(60780, 'el-borma', 'tataouine');

-- 
-- Contraintes pour les tables exportées
-- 

-- 
-- Contraintes pour la table `mesure`
-- 
ALTER TABLE `mesure`
  ADD CONSTRAINT `mesure_ibfk_1` FOREIGN KEY (`idstation`) REFERENCES `station` (`idstation`) ON DELETE CASCADE ON UPDATE CASCADE;
