<?php
    /*contacter avec notre base*/
    mysql_connect('localhost','root','') or die ("echec dans la base de donnees..");
    mysql_select_db("bdTic2021");
   
    /* recuperer les donnees */
    $nom=$_POST['sel1'];        
    $saison=$_POST['sel2'];         
    $an=$_POST['an'];               
    $t=$_POST['temp'];
    $p=$_POST['pl'];
    
    /*recuperer id de station */
    $sql="select idStation from station where nom='$nom'";
    $result=mysql_query($sql) or die ("echec dans la table station !");
    $row=mysql_fetch_array($result);
    $id=$row[0];

    /* requete a traite */
    $sql0="select * from mesure where idStation=$id and annee='$an' and saison='$saison'";
    $result0=mysql_query($sql0);

    /* verification d'existance */
    if ($result0) {
        if (mysql_num_rows($result0)>0) {
            echo 'mesure deja enregestrer';
            exit();
        } else {
            /*insertion de mesure*/
            $sql1="insert into mesure values ($id,'$an','$saison','$t','$p')";
            $result1=mysql_query($sql1);
            if ($result1) {
                echo 'Ajout effecter avec success';
                exit();
            } else 
            {
                echo 'echec dans linsertion du mesure';
                exit();
            }
        }
    } else {
        echo 'echec de lopperation';
            exit();
    }
?>