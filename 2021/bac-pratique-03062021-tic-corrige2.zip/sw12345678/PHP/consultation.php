<html>
<head><title>Resultat| Consulation</title></head>
<body>
<?php
     /*contacter avec notre base*/
    mysql_connect('localhost','root','') or die ("echec dans la base de donnees..");
    mysql_select_db("bdTic2021");

    /* recuperer les donnees */
    $st=$_POST['st'];
    $mes=$_POST['clim'];
    
    /*recuperer id de station */
    $sql="select idStation from station where nom='$st'";
    $result=mysql_query($sql) or die ("echec dans la table station !");
    $row=mysql_fetch_array($result);
    $id=$row[0];


     /* requete a traite */
    $sql="select saison,annee,tempurature,pluie from mesure where idStation=$id";
    $result=mysql_query($sql) or die ("echec dans la selection");

    /* l'affichage dans un tbleau */
    echo '<center><p>Station : '.$st.'</p><table border=2 style="width: 50%;">
    <tr>
    <th>Saison</th>
    <th>Annee</th>
    <th>Mesure enregestrer ('.$mes.')</th>
    </tr>';
    while ($row=mysql_fetch_array($result)) {
      echo'
        <tr>
        <td>'.$row[0].'</td>
        <td>'.$row[1].'</td>
        <td>'.$row[$mes].'</td>
        </tr>
        ';
    }
    echo '</table></center>';

?>
</body>
</html>