-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeudi 03 Juin 2021 à 18:40
-- Version du serveur: 5.0.27
-- Version de PHP: 5.2.0
-- 
-- Base de données: `bdtic2021`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `mesure`
-- 

CREATE TABLE `mesure` (
  `idStation` int(11) NOT NULL,
  `annee` int(11) NOT NULL,
  `saison` varchar(9) NOT NULL,
  `tempurature` decimal(5,2) NOT NULL,
  `pluie` int(11) NOT NULL,
  PRIMARY KEY  (`idStation`,`annee`,`saison`),
  KEY `fk` (`idStation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `mesure`
-- 

INSERT INTO `mesure` (`idStation`, `annee`, `saison`, `tempurature`, `pluie`) VALUES 
(60715, 2018, 'ete', 30.60, 24),
(60715, 2018, 'hiver', 13.50, 150),
(60715, 2019, 'printemps', 25.60, 80),
(60731, 2018, 'ete', 33.60, 10),
(60731, 2018, 'hiver', 17.60, 100),
(60731, 2019, 'automme', 30.00, 11),
(60780, 2019, 'ete', 42.30, 0),
(60780, 2019, 'hiver', 16.60, 10);
