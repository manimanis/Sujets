-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Mer 09 Juin 2021 à 12:18
-- Version du serveur: 5.5.27-log
-- Version de PHP: 5.4.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bd062021`
--

-- --------------------------------------------------------

--
-- Structure de la table `mesure`
--

CREATE TABLE IF NOT EXISTS `mesure` (
  `IdStation` int(5) NOT NULL,
  `Annee` int(4) NOT NULL,
  `Saison` varchar(9) NOT NULL,
  `Temperature` decimal(5,0) NOT NULL,
  `Pluie` int(4) NOT NULL,
  PRIMARY KEY (`IdStation`,`Annee`,`Saison`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `mesure`
--

INSERT INTO `mesure` (`IdStation`, `Annee`, `Saison`, `Temperature`, `Pluie`) VALUES
(60715, 2018, 'Eté', '31', 24),
(60715, 2018, 'Hiver', '14', 150),
(60715, 2019, 'Printemps', '26', 80),
(60731, 2018, 'Eté', '34', 10),
(60731, 2018, 'Hiver', '18', 100),
(60731, 2019, 'Automne', '30', 11),
(60780, 2019, 'Eté', '42', 0),
(60780, 2019, 'Hiver', '17', 10);

-- --------------------------------------------------------

--
-- Structure de la table `station`
--

CREATE TABLE IF NOT EXISTS `station` (
  `IdStation` int(5) NOT NULL,
  `Nom` varchar(30) NOT NULL,
  `Ville` varchar(30) NOT NULL,
  PRIMARY KEY (`IdStation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `station`
--

INSERT INTO `station` (`IdStation`, `Nom`, `Ville`) VALUES
(60715, 'Carthage', 'Tunis'),
(60731, 'Enfidha-Aéroport', 'Sousse'),
(60780, 'El-Borma', 'Tataouine');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `mesure`
--
ALTER TABLE `mesure`
  ADD CONSTRAINT `mesure_ibfk_1` FOREIGN KEY (`IdStation`) REFERENCES `station` (`IdStation`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
