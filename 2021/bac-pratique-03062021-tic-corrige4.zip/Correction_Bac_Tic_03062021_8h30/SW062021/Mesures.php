<html>
<head>
  <meta charset="utf-8">
  <title>Page Mesures.php</title>
</head>
<body "bgcolor="#CCFF99">
<?php
mysql_connect("localhost","root","");
mysql_select_db("BD062021");
$station=$_POST['station'];
$saison=$_POST['saison'];
$annee=$_POST['annee'];
$temperature=$_POST['temperature'];
$pluie=$_POST['pluie'];
$req="select *
      from Mesure
	  where IdStation='$station'
	        and Annee='$annee'
			and Saison='$saison'";
$res=mysql_query($req);
if(mysql_num_rows($res)!= 0)
  echo "<font color='red' size='6'><center> Mesures déjâ enregistrées</center></font>";
else
{ $req="insert into Mesure values('$station','$annee','$saison','$temperature','$pluie')";
  $res=mysql_query($req);
  if ($res==NULL)
    echo "<font color='red' size='6'><center> Opération d'ajout echouée</center></font>";
  else
    echo "<font color='red' size='6'><center> Ajout effectué avec succès!!</center></font>";
}
echo "<font color='red' size='6'><center> Bienvenu!!</center></font>";
?>
</body>
</html>