<html>
<head>
  <meta charset="Latin1">
  <title>Page Consultation.php</title>
</head>
<body "bgcolor="#CCFF99">
<?php
mysql_connect("localhost","root","");
mysql_select_db("BD062021");
$station=$_POST['station'];
$climat=$_POST['climat'];
$req1="select Nom
       from Station
	   where IdStation='$station'";
$res1=mysql_query($req1);
$tab1=mysql_fetch_array($res1);
echo "Station : <b>".$tab1['Nom']."</b>";
echo("<table border='1' width='40%'>
	<tr><th width='140'>Saison</th>
		<th width='140'>Annee</th>
		<th width='240'>Mesure enregistree</th>
	</tr>");
$unite=" mm";	
if ($climat=="Temperature") $unite=" C";
$req2="select *
       from Mesure
       where IdStation='$station'";
$res2=mysql_query($req2);
while($tab2=mysql_fetch_array($res2)){
  echo "<tr><td width='140'>".$tab2['Saison']."</td>
          <td width='140'>".$tab2['Annee']."</td>
	      <td width='240'>".$tab2[$climat].$unite."</td>
        </tr>";
}
?>
</body>
</html>