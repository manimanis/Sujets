<meta charset="utf-8">

<?php

#Connexion & Sélection de la base de données

mysql_connect("localhost","root","");
mysql_select_db("SW12345678");


#Recuperation des données du formulaire

$code=$_POST['code'];
$cin=$_POST['cin'];
$dur=$_POST['dur'];

#Verification de l'existence de l'habit identifié par le code saisi

$req1="SELECT * from habit where codeHab='$code';";
$res1=mysql_query($req1);
if (mysql_num_rows($res1)==0) {
	echo "Erreur : Habit inexistant !";
}
else
{
	$req2="SELECT * from habit where codeHab='$code' and disponible='D';";
	$res2=mysql_query($req2);
	if (mysql_num_rows($res2)==0) {
		echo "Erreur : Habit déjà loué";
	}
	else
	{
		$req3="SELECT * from client where cin='$cin';";
		$res3=mysql_query($req3);
		if (mysql_num_rows($res3)==0) {
			echo "Erreur : Client inexistant";
		}
		else
		{
			$req4="INSERT into location VALUES(now(),'$code','$cin','$dur');";
			$res4=mysql_query($req4);
			if (mysql_affected_rows()>0) {
				$req5="UPDATE habit 
				SET disponible='N' where codeHab='$code';";
				$res5=mysql_query($req5);
				if (mysql_affected_rows()>0) {
					echo "Location effectuée avec succéss";
				}
			}
		}
	}
}

?>