function alpha(ch) {
    for (var i = 0; i < ch.length; i++) {
        var c = ch.charAt(i).toUpperCase();
        if (c < "A" || c > "Z") {
            return false;
        }
    }
    return true;
}

function verif1() {
    // Categorie: Selection obligatoire
    if (document.getElementById("s1").selectedIndex === 0) {
        alert("Selection obligatoire d'une catégorie");
        return false;
    }

    // Description: Une chaine de 10 à 100 caractère dont le premier et le dernier sont des entiers
    var des = document.getElementById("des").value;
    var n1 = des.substr(0, 1);
    var n2 = des.substr(des.length - 1, 1);

    if (des.length < 10 || des.length > 100 || !alpha(n1) || !alpha(n2)) {
        alert("Verifier le description");
        return false;
    }

    // Taille: Sélection obligatoire d'une taille
    var r1 = document.getElementById("r1").checked;
    var r2 = document.getElementById("r2").checked;
    var r3 = document.getElementById("r3").checked;
    var r4 = document.getElementById("r4").checked;

    if (!r1 && !r2 && !r3 && !r4) {
        alert("Sélection obligatoire d'une taille");
        return false;
    }

    // Prix: un nombre entre 100 et 2000
    var prix = document.getElementById("prix").value;

    if (isNaN(prix) || Number(prix) < 100 || Number(prix) > 2000) {
        alert("Verifier le prix");
        return false;
    }

    return true;
}

function verif2() {
    // Code: entier supérieur ou égal à 1
    var code = document.getElementById("code").value;

    if (isNaN(code) || Number(code) < 1) {
        alert("Verifier le code d'habit");
        return false;
    }

    // Cin: Une chaine de 8 chiffres qui commencent par 0 ou 1
    var cin = document.getElementById("cin").value;

    if (cin.length !== 8 || isNaN(cin) || !(cin.charAt(0) === "0" || cin.charAt(0) === "1")) {
        alert("Verifier le ncin");
        return false;
    }

    var dur = document.getElementById("dur").value;

    if (isNaN(dur) || Number(dur) < 1 || Number(dur) > 4) {
        alert("Verifier la durée");
        return false;
    }

    return true;
}
