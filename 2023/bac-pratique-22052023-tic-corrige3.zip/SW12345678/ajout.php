<meta charset="utf-8">

<?php

# Connexion & Sélection de la base de données

mysql_connect("localhost", "root", "");
mysql_select_db("sw12345678");

# Recuperation des données du formulaire

$cat = $_POST['s1'];
$des = $_POST['des'];
$taille = $_POST['r'];
$prix = $_POST['prix'];

# Requête de l'insertion d'un habit dans la base de données

$req1 = "INSERT INTO habit VALUES('', '$des', '$taille', '$prix', 'D', '$cat');";
$res1 = mysql_query($req1);

# Verification de l'insertion d'un nouveau habit à la base de données
if (mysql_affected_rows() > 0) {
    echo "Enregistrement réalisé avec succès";
} else {
    echo "Enregistrement échoué";
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>
