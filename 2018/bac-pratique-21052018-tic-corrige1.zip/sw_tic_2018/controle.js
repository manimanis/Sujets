﻿function generercaptcha(){
	var min=1;
	var max=26;
	//pour determiner ASCII de "A"==>"A".charCodeAt(0));
	//pour determiner ASCII de "a"==>"a".charCodeAt(0));
	var car='';
	for(i=0;i<10;i++){
		var k=Math.floor(Math.random() * (max - min + 1)) + min;
		if(k%2==0){
			car=car+String.fromCharCode(k+"A".charCodeAt(0)-1);}
		else{
			car=car+String.fromCharCode(k+"a".charCodeAt(0)-1);}
	}
	//affecter le code dans le formulaire
	document.f.code.value=car;
}
function verif(){
	var idhotel=document.f.idhotel.selectedIndex;
	
	
	var code=document.f.code.value;
	var reponse=document.f.reponse.value;
	var majuscule="AZERTYUIOPMLKJHGFDSQWXCVBN";
	if(idhotel<=0){
		alert("choisir hotel");
		return false;}
	if((document.f.noteaccueil[0].checked==false)&&(document.f.noteaccueil[1].checked==false)&&(document.f.noteaccueil[2].checked==false)){
	alert("note accueil à cocher");
	return false;}
	
	if((document.f.noterest[0].checked==false)&&(document.f.noterest[1].checked==false)&&(document.f.noterest[2].checked==false)){
	alert("note restauration à cocher");
	return false;}
		nb=0;
	alert("code="+code);
	for(i=0;i<code.length;i++){
		if((code.charAt(i)>="A")&&(code.charAt(i)<="Z")){
			nb=nb+1;}}
			
	alert("nb maj dans "+code+"="+nb);
	if((reponse=="")||(nb!=Number(reponse))){
		alert("nombre de maj incorrect");
		return false;}
}