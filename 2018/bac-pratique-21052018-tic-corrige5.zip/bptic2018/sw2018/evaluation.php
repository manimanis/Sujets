<!DOCTYPE html>

<html>

<head>
  <title>Hello!</title>
</head>

<body bgcolor="FFFF66">

<?php
mysql_connect("localhost","root","");
mysql_select_db("bd2018");
$a=$_POST["D1"];
$b=$_POST["R1"];
$c=$_POST["R2"];
 $x=0;
 if(isset($_POST["C1"]))
 {
      $d=$_POST["C1"];
      $x+=$d;
 }
  if(isset($_POST["C2"]))
 {
      $d=$_POST["C2"];
      $x+=$d;
 }
 if(isset($_POST["C3"]))
 {
      $d=$_POST["C3"];
      $x+=$d;
 }
 $da=date('Y-m-d');
$req="select * from evaluation where idhotel='$a' and dateeval='$da'";
$r=mysql_query($req);
if(mysql_num_rows($r)!=0)
{
     echo "<font size=6 color='red'><center>Cet hotel est deja evalue!</center></font>" ;
}
else
{
    $req="insert into evaluation values('$da','$a','$b','$c','$x')";
    $r=mysql_query($req);
if($r!=NULL)
{
     echo "<font size=6 color='red'><center>Evaluation enregistee avec succes!</center></font>" ;
}
}

?>

</body>
</html>