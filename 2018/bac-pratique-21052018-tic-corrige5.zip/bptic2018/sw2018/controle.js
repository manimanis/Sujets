
function generercaptcha()
{
ch="";i=1;m=0;
while(i<=10)
{
   do
   {  x=Math.random();
      n=Math.round(x*100);
   
   
   }while((n<1)||(n>26));
   
   
   c=String.fromCharCode(n+96);
   
   if(n%2==0)
   {
    c=c.toUpperCase();
    m++
    }
   ch=ch+c;
  
  i++;
 }

 f.T1.value=ch;
 return m;
 
}
function verif()
{
   if(f.D1.selectedIndex==0)
    {
      alert("La s�l�ction d'un h�tel est obligatoire!");
      return false;
    }
    if((f.R1.value!=1)&&(f.R1.value!=2)&&(f.R1.value!=3))
    {
      alert("L'evaluation d'accueil est obligatoire!");
      return false;
    }
    if((f.R2.value!=1)&&(f.R2.value!=2)&&(f.R2.value!=3))
    {
      alert("L'evaluation de restauration est obligatoire!");
      return false;
    }
    nlm=generercaptcha();
    nb=Number(f.T2.value);
    
    if(nb!=nlm)
    {
      alert("Le nombre de caract�res de reponse doit etre egal au nombre de lettres maj !");
      return false;
    }
    
}

