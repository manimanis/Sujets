
function compterMajus(ch){
var n=0;
for (i=0;i<ch.length;i++)
{if ((ch.charAt(i)>="A") && (ch.charAt(i)<="Z"))
 ++n;
}
return n;
}

function verif(f){
var h = f.hot.selectedIndex;  // hotel s�lectionn�
var rep = f.reponse.value;    // r�ponse
var capt = f.captcha.value;   // captcha

if (h==0) {
alert("Vous devez s�lectionner un hotel"); return false;
}
else if (!(f.acc[0].checked) && !(f.acc[1].checked) && !(f.acc[2].checked)){
alert("Vous devez �valuer l'accueil");  return false;

}
else if (!(f.rest[0].checked) && !(f.rest[1].checked) && !(f.rest[2].checked)){
alert("Vous devez �valuer la restauration");  return false;

}
else if (compterMajus(capt) != Number(rep)){
alert("La r�ponse de Captcha est incorrecte");
f.reponse.focus(); return false;
}
}



function genererCaptcha(){
var ch ="";
for (i=0;i<10; i++){
k = Math.floor(Math.random()*26)+1;
if (k%2==0){
// majuscule
ch += String.fromCharCode(k+65);
}
else {
// minuscule
ch += String.fromCharCode(k+97);
}
}
document.f.captcha.value=ch;
}