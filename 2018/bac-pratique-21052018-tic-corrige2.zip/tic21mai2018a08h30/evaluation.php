<?php
$h = $_POST['hot'];  //  hotel
$a = $_POST['acc'];  // accueil
$r = $_POST['rest']; // restauration

// Note extra:
$s=0;
foreach($_POST['extra'] as &$valeur)
{$s += $valeur;}

// date syst�me:
$d = date('Y-m-d');

// connexion au serveur:
$id =mysqli_connect("localhost","root","") or die ("Erreur de connexion au serveur");

// s�lection de la base de donn�es:
$db = mysqli_select_db($id, "dbtic2018") or die ("Erreur de connexion a la base");

// requete 1:
$sql1 = "select * from evaluation where (idHotel ='$h') and (dateEval='$d')";

$res1 = mysqli_query($id, $sql1) or die ("Erreur dans la requete ".mysqli_error($id));

if (mysqli_num_rows($res1) !=0) $msg="Erreur: Cet hotel est deja evalu�"; 
else
{

// requete 2:
$sql2 = "INSERT INTO evaluation (dateeval,idhotel,noteaccueil,noterest, noteextra)";
$sql2 .= " VALUES ('$d','$h','$a','$r','$s')";

$res2 = mysqli_query($id, $sql2) or die ("Erreur dans la requete ".mysqli_error($id));

if (mysqli_affected_rows($id) ==0) $msg ="Erreur: aucun ajout"; 
else $msg= 'Commentaire ajoute ';
}

// afficher les hotels dans un tableau:
$sql3 = "select h.nomhotel, avg(noteaccueil), avg(noterest),avg(noteextra)";
$sql3 .= " from evaluation e , hotel h";
$sql3 .= " where e.idhotel=h.idhotel group by 1 ";

$res3 = mysqli_query($id, $sql3) or die ("Erreur: dans la requete ".mysqli_error($id));

echo "<table cellspacing=5 cellpadding=5 width=50% align=center>";
echo "<tr><td colspan=5>".$msg."</td></tr>";
echo "<tr bgcolor=#E743A9>";
echo "<td align=center><b>N<sup>o</sup></b></td>";
echo "<td align=center><b>Hotel</b></td>";
echo "<td align=center><b>Accueil</b></td>";
echo "<td align=center><b>Restauration</b></td>";
echo "<td align=center><b>Extra</b></td>";
echo "</tr>";
$i=0;
while($t=mysqli_fetch_array($res3,MYSQLI_NUM)){
$i++;
echo "<tr bgcolor=#FAD3EC align=center>";
echo "<td>".$i."</td>";
echo "<td>".$t[0]."</td>";
echo "<td>".$t[1]."</td>";
echo "<td>".$t[2]."</td>";
echo "<td>".$t[3]."</td>";
echo "</tr>";


} 
echo "</table>";
echo "<br>";
echo "<center>";

 // lien de retour vers la page evaluation.html
echo "<a href=evaluation.html title='Evaluation' target=_self>Retour</a>";

// fermeture de la  conexion:
mysqli_close($id);

?>