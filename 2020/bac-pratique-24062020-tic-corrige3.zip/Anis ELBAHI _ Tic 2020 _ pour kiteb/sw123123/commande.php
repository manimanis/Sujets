<?
mysql_connect('localhost','root','');
mysql_select_db('bd123123');

//improtation des valeurs
$tp=$_POST['D1'];
$q=$_POST['T1'];
$t=$_POST['T2'];
$mp=$_POST['T3'];

//verifier si le numero de tel et le mot de passe n'existent pas.
$req1="select * from client where Tel='$t' and Motpass='$mp'";
$res1=mysql_query($req1);
if(mysql_num_rows($res1)==0)
{
	echo('N° Tél ou mot de passe erroné!');
}
else
   {//ajouter la commande à la table commande 
    
	$dt=date('Y-m-d H:i:s'); //la date systeme
	$req2="insert into commande values ('$tp','$t','$dt',$q)";
	$res2=mysql_query($req2);
	if(mysql_affected_rows()!=0)
	echo('Opération réussie');
    }
?>