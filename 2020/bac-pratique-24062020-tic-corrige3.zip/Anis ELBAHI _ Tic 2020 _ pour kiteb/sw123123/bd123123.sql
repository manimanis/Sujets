-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Jeudi 25 Juin 2020 à 21:48
-- Version du serveur: 4.1.9
-- Version de PHP: 4.3.10
-- 
-- Base de données: `bd123123`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `client`
-- 

CREATE TABLE `client` (
  `Tel` varchar(8) NOT NULL default '',
  `Nom` varchar(25) NOT NULL default '',
  `Prenom` varchar(25) NOT NULL default '',
  `Adresse` varchar(100) NOT NULL default '',
  `MotPass` varchar(6) NOT NULL default '',
  PRIMARY KEY  (`Tel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `client`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `commande`
-- 

CREATE TABLE `commande` (
  `IdPizza` char(3) NOT NULL default '',
  `Tel` varchar(8) NOT NULL default '',
  `DateCmd` datetime NOT NULL default '0000-00-00 00:00:00',
  `QteCmd` int(11) NOT NULL default '0',
  PRIMARY KEY  (`IdPizza`,`Tel`,`DateCmd`),
  KEY `Tel` (`Tel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `commande`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `pizza`
-- 

CREATE TABLE `pizza` (
  `IdPizza` char(3) NOT NULL default '',
  `NomPizza` varchar(30) NOT NULL default '',
  `Details` varchar(200) NOT NULL default '',
  `Prix` decimal(6,3) NOT NULL default '0.000',
  PRIMARY KEY  (`IdPizza`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `pizza`
-- 

INSERT INTO `pizza` VALUES ('Fmr', 'Fruits de mer', 'Tomate, Mozzarella, Fruits de mer', 18.500);
INSERT INTO `pizza` VALUES ('Mgh', 'Margherita', 'Tomate, Mozzarella, Basilic', 8.000);
INSERT INTO `pizza` VALUES ('Nap', 'Napolitaine', 'Tomate, Mozzarella, Thon, Anchois', 12.000);
INSERT INTO `pizza` VALUES ('Nep', 'Neptune', 'Tomate, Mozzarella,Thon', 10.500);
INSERT INTO `pizza` VALUES ('Roy', 'Royale', 'Tomate, Mozzarella,jambon, Champignon', 14.500);

-- 
-- Contraintes pour les tables exportées
-- 

-- 
-- Contraintes pour la table `commande`
-- 
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_3` FOREIGN KEY (`IdPizza`) REFERENCES `pizza` (`IdPizza`),
  ADD CONSTRAINT `commande_ibfk_4` FOREIGN KEY (`Tel`) REFERENCES `client` (`Tel`);
