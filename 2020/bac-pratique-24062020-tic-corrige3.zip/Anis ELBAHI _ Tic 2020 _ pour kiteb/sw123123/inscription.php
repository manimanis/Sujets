<?
mysql_connect('localhost','root','');
mysql_select_db('bd123123');

//improtation des valeurs
$n=$_POST['T1'];
$p=$_POST['T2'];
$t=$_POST['T3'];
$a=$_POST['S1'];
$mp=$_POST['T4'];

//verifier si le numero de tel n'existe pas.
$req1="select * from client where Tel='$t'";
$res1=mysql_query($req1);
if(mysql_num_rows($res1)==0)
{
	//insertion du client
	$req2="insert into client values ('$t', '$n', '$p','$a','$mp' )";
	$res2=mysql_query($req2);
	if(mysql_affected_rows()>0)
	echo('Inscription effectuée avec succès');
}
else
   {//verifier si le client est deja inscrit ou non
    $req3="select * from client where Tel='$t' and nom='$n' and prenom='$p'";
    $res3=mysql_query($req3);
	if(mysql_num_rows($res3)!=0)
	echo('Client deja inscrit !');
    else
	// verifier si un autre client possede le meme numero de tel 
	echo('Erreur : Tél, Nom ou Prénom erroné !');
    }
?>