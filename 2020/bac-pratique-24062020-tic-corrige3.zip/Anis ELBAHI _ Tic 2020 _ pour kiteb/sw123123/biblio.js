function alpha(x)
{
	x=x.toUpperCase();
	ok=true;
	for(i=0;i<x.length;i++)
		if(x.charAt(i)<'A' || x.charAt(i)>'Z')
			ok=false;
return (ok);	
}

function num(x)
{
	ok=true;
	for(i=0;i<x.length;i++)
		if(x.charAt(i)<'0' || x.charAt(i)>'9')
			ok=false;
return (ok);	
}

function verif1()
{
//verification du nom
n=f.T1.value;
if(alpha(n)==false || n.length < 3)	
{alert(' nom invalide '); return false;}

//verification du pr�nom
p=f.T2.value;
if(alpha(p)==false || p.length < 3)	
{alert(' pr�nom invalide '); return false;}	

//verification du t�l�phone
t=f.T3.value;
if(num(t)==false || t.length !=8 ||t.charAt(0)<='1')
{alert(' t�l�phone invalide '); return false;}		

//verification de l'adresse
a=f.S1.value;
if(a.length < 10)
{alert(' Adresse invalide '); return false;}

//verification du mot de passe
mp=f.T4.value;
if(mp.length !=6 || mp.indexOf(" ")!=-1)
{alert(' mot de passe invalide '); return false;}

//verification de la confirmation du mot de passe
c=f.T5.value;
if(c!=mp)
{alert(' verifier le mot de passe '); return false;}	
	
}


function verif2()
{
//verification du type de pizza
tp=f.D1.value;
if(tp=="")	
{alert(' il faut choisir le type '); return false;}

//verification de la quantit�
q=f.T1.value;
if(num(q)==false || q<1 || q>5)
{alert(' la quantit� SVP '); return false;}	

//verification du t�l�phone
t=f.T2.value;
if(num(t)==false || t.length !=8 ||t.charAt(0)<='1')
{alert(' t�l�phone invalide '); return false;}		

//verification du mot de passe
mp=f.T3.value;
if(mp.length !=6 || mp.indexOf(" ")!=-1)
{alert(' mot de passe invalide '); return false;}
}
