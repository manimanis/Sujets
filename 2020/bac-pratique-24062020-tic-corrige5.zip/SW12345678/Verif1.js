function Alphabetique(Ch){
  var Lettres='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
  for(var i=0; i<Ch.length; i++){
    if(Lettres.indexOf(Ch[i].toUpperCase())<0) return false;
  }
  return true; 
}


function Verif(){
   
    var Nom=client.nom.value;
    var Prenom=client.prenom.value;
    var Tel=client.tel.value;
    var Adresse=client.adr.value;
	 var Pwd=client.pwd.value;
    var CPwd=client.cpwd.value;

    if (Nom.length<3  || !Alphabetique(Nom)){
        alert('Champ Nom non valide') ; return false;
    }
    if (Prenom.length<3 || !Alphabetique(Prenom)){
        alert('Champ prénom  non valide') ; return false;
    }
  
    if(Tel.length!=8 || Tel.charAt(0)<1 || isNaN(Tel)==true){
        alert('N° de téléphone invalide') ; return false;
    }
  if (Adresse.length<10){
        alert('Adresse non valide') ; return false;
    }
      if(Pwd.length!=6 || Pwd.indexOf(" ")!=-1 ){
        alert('Mot depasse invalide') ; return false;
    
    }
	if(Pwd!=CPwd){
        alert('Mot depasse n’est pas identique') ; return false;
    
    }
	
}

