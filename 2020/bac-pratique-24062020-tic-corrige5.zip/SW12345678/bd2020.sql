-- --------------------------------------------------------
-- Hôte:                         127.0.0.1
-- Version du serveur:           5.6.17 - MySQL Community Server (GPL)
-- Serveur OS:                   Win32
-- HeidiSQL Version:             9.1.0.4867
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Export de la structure de la base pour bd2020
CREATE DATABASE IF NOT EXISTS `bd2020` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `bd2020`;


-- Export de la structure de table bd2020. client
CREATE TABLE IF NOT EXISTS `client` (
  `Tel` varchar(8) NOT NULL,
  `Nom` varchar(25) NOT NULL,
  `Prenom` varchar(25) NOT NULL,
  `Adresse` varchar(100) NOT NULL,
  `MotPass` varchar(6) NOT NULL,
  PRIMARY KEY (`Tel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table bd2020.client: ~9 rows (environ)
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` (`Tel`, `Nom`, `Prenom`, `Adresse`, `MotPass`) VALUES
	('', '', '', '', '');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;


-- Export de la structure de table bd2020. commande
CREATE TABLE IF NOT EXISTS `commande` (
  `IdPizza` varchar(3) NOT NULL,
  `tel` varchar(8) NOT NULL,
  `DateCmd` datetime NOT NULL,
  `QteCmd` int(11) NOT NULL,
  KEY `DateCmd` (`DateCmd`),
  KEY `tel` (`tel`),
  KEY `IdPizza` (`IdPizza`),
  CONSTRAINT `FK__client` FOREIGN KEY (`tel`) REFERENCES `client` (`Tel`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK__pizza` FOREIGN KEY (`IdPizza`) REFERENCES `pizza` (`IdPizza`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table bd2020.commande: ~2 rows (environ)
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;


-- Export de la structure de table bd2020. pizza
CREATE TABLE IF NOT EXISTS `pizza` (
  `IdPizza` varchar(3) NOT NULL,
  `NomPizza` varchar(30) NOT NULL,
  `Details` varchar(200) NOT NULL,
  `Prix` decimal(6,3) NOT NULL,
  PRIMARY KEY (`IdPizza`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Export de données de la table bd2020.pizza: ~4 rows (environ)
/*!40000 ALTER TABLE `pizza` DISABLE KEYS */;
INSERT INTO `pizza` (`IdPizza`, `NomPizza`, `Details`, `Prix`) VALUES
	('Fmr', 'Fruit de mer', 'Tomate,Mozzarelle,Fruits de mer', 18.500),
	('Mgh', 'Margherita', 'Tomate,Mozzarella,Basilic', 8.000),
	('Nap', 'Napolitaine', 'Tomate,Mozzarella,Thon,Anchois', 12.000),
	('Nep', 'Neptune', 'Tomate,Mozzarella,thon', 10.500),
	('Roy', 'Royale', 'Tomate,Mozzarelle,Jambon,Champignon', 14.500);
/*!40000 ALTER TABLE `pizza` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
