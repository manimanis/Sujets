<?php
echo "<meta charset='utf-8'>";
$pwd=$_POST["pwd"];
$tel=$_POST["tel"];
$chp=$_POST["c_pizza"];
$qte=$_POST["qte"];
$da=date('Y-m-d h:i:s');
mysql_connect('127.0.0.1','root','') or exit(mysql_error());

//Sélection de la BD
mysql_select_db('bd2020') 
  or die("Erreur connexion BD ".mysql_error());
  // vérification  l'existence de couples  de Numéro du téléphone et mots de masse d'un client donner
  $req_sel=mysql_query("SELECT Tel FROM Client WHERE Tel='$tel' AND MotPass='$pwd'");
  //si le numéro du téléphone  et mot de passe existe pas dans la base
   if(mysql_num_rows($req_sel)!=0){
	  $req_ins="INSERT INTO commande VALUES('$chp','$tel','$da','$qte')";
             $q=mysql_query($req_ins) or die("Problème d'insertion ".mysqli_error());
	         if(mysql_affected_rows()) echo ("Opération réussie");
		}
		
?>