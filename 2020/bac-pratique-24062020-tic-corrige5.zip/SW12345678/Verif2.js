

function Verif2(){
   
    var Qte=Number(commande.qte.value);
    var Tel=commande.tel.value;
	 var Pwd=commande.pwd.value;
    var Cpz=commande.c_pizza.selectedIndex;
  if(Cpz==0){
	  alert('Sélection obligatoire d’une pizza');return false;
  }
    if(Tel.length!=8 || Tel.charAt(0)<1 || isNaN(Tel)==true){
        alert('N° de téléphone invalide') ; return false;
    }
	if ((Qte<1) ||(Qte>5))
{
   alert ('La quantité doit etre un nombre compris entre 1 et 5');
   return false;
   }
   if(Pwd.length!=6 || Pwd.indexOf(" ")!=-1 ){
        alert('Mot depasse invalide') ; return false;
    
    }
}

