<?php


echo "<meta charset='utf-8'>";
$tel=$_POST["tel"];
$nom=$_POST["nom"];
$prenom=$_POST["prenom"];
$adr=$_POST["adr"];
$pwd=$_POST["pwd"];
$pwdc=$_POST["cpwd"];
mysql_connect('127.0.0.1','root','') or exit(mysql_error());

//Sélection de la BD
mysql_select_db('bd2020') 
  or die("Erreur connexion BD ".mysql_error());
  // vérification de l'existence de Numéro du téléphone d'un client donner
  $req_sel=mysql_query("SELECT Tel FROM Client WHERE Tel='$tel'");
  //si le numéro du téléphone n'existe pas dans la base
   if(mysql_num_rows($req_sel)==0){
	//donc on l'ajouter dans la base de donnée
	         $req_ins="INSERT INTO Client VALUES('$tel','$nom','$prenom','$adr','$pwd')";
             $q=mysql_query($req_ins) or die("Problème d'insertion ".mysqli_error());
	         if(mysql_affected_rows()) echo ("inscription effectué avec succés");}
//si le numéro du téléphone exixte dans la base			 
else if(mysql_num_rows($req_sel)!=0){
//sélectioner le trio tel,nom,prénom
       $req_sel2=mysql_query("SELECT Tel FROM Client WHERE  Tel='$tel' AND Nom='$nom' AND Prenom='$prenom'");
       //tester l'existance de trio 
	    if(mysql_num_rows($req_sel2)!=0){
        echo 'Client déjà inscrit';	}
		else{
			echo'Erreur : Tél,Nom ou Prénom erroné !';
		}
		}
?>