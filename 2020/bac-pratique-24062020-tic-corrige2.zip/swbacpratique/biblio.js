function verif1(){
    nom=document.f.T1.value;
    pre=document.f.T2.value;
    tel=document.f.T3.value;
    adr=document.f.S1.value;
    mp=document.f.T4.value;
    cmp=document.f.T5.value;
    if((nom.length<3)||(!alpha(nom))){alert("nom incorrect");return false;}
    if((pre.length<3)||(!alpha(pre))){alert("prénom incorrect");return false;}
    if((tel.length!=8)||(!num(tel))||(tel.charAt(0)<=1)){alert("téléphone incorrect");return false;}
    if(adr.length<10){alert("adresse incorrecte");return false;}
    if((mp.length!=6)||(mp.indexOf(" ")!=-1)){alert("mot de passe incorrect");return false;}
    if(mp!=cmp){alert("vérifiez votre mot de passe");return false;}
    
}
function verif2(){
    valeurtp=document.f.D1.selectedIndex;
    qte=document.f.T1.value;
    tel=document.f.T2.value;
    mp=document.f.T3.value;
    if(valeurtp<=0){alert("type de pizza obligatoire");return false;}
    if((!num(qte))||(qte<1)||(qte>5)){alert("nombre entre 1 et 5");return false;}
    if((tel.length!=8)||(!num(tel))||(tel.charAt(0)<=1)){alert("téléphone incorrect");return false;}
    if((mp.length!=6)||(mp.indexOf(" ")!=-1)){alert("mot de passe incorrect");return false;}
}
function alpha(ch) {
    ch = ch.toUpperCase();
    for (i = 0; i < ch.length; i++)
        if ((ch.charAt(i) < "A") || (ch.charAt(i) > "Z")) return false;
    return true;
}
    function num(ch){
    chaine="0123456789";
    for(i=0;i<ch.length;i++)
        if(chaine.indexOf(ch.charAt(i))==-1)return false;
    return true;}