-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- Généré le : Mercredi 24 Juin 2020 à 10:09
-- Version du serveur: 5.0.27
-- Version de PHP: 5.2.0
-- 
-- Base de données: `bdbacpratique`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `client`
-- 

CREATE TABLE `client` (
  `tel` varchar(8) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `motpass` varchar(6) NOT NULL,
  PRIMARY KEY  (`tel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `client`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `commande`
-- 

CREATE TABLE `commande` (
  `idpizza` varchar(3) NOT NULL,
  `tel` varchar(8) NOT NULL,
  `datecmd` datetime NOT NULL,
  `qtecmd` int(11) NOT NULL,
  PRIMARY KEY  (`idpizza`,`tel`,`datecmd`),
  KEY `tel` (`tel`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `commande`
-- 


-- --------------------------------------------------------

-- 
-- Structure de la table `pizza`
-- 

CREATE TABLE `pizza` (
  `idpizza` varchar(3) NOT NULL,
  `nompizza` varchar(30) NOT NULL,
  `details` varchar(200) NOT NULL,
  `prix` decimal(6,3) NOT NULL,
  PRIMARY KEY  (`idpizza`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Contenu de la table `pizza`
-- 

INSERT INTO `pizza` (`idpizza`, `nompizza`, `details`, `prix`) VALUES 
('fmr', 'fruits de mer', 'tomate, mozzarella, fruits de mer', 18.500),
('mgh', 'margherita', 'tomate, mozzarella, basilic', 8.000),
('nap', 'napolitaine', 'tomate, mozzarella, thon, anchois', 12.000),
('nep', 'neptune', 'tomate, mozzarella, thon', 10.500),
('roy', 'royale', 'tomate, mozzarella, jambon, champignon', 14.500);

-- 
-- Contraintes pour les tables exportées
-- 

-- 
-- Contraintes pour la table `commande`
-- 
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`tel`) REFERENCES `client` (`tel`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idpizza`) REFERENCES `pizza` (`idpizza`) ON DELETE CASCADE ON UPDATE CASCADE;
