<meta charset="utf-8">
<?php
mysql_connect("localhost","root")or die (mysql_error());
mysql_select_db("bdbacpratique")or die(mysql_error());
$idpizza=$_POST["D1"];
$qte=$_POST["T1"];
$tel=$_POST["T2"];
$mdp=$_POST["T3"];
$dc=date("Y-m-d H:i:s");
$Q="select *
    from client
    where motpass='$mdp'and tel='$tel'";
$R=mysql_query($Q)or die(mysql_error());
if(mysql_num_rows($R)==0)die("N° Tél ou mot de passe erroné !");
$Q="insert into commande values('$idpizza','$tel','$dc','$qte')";
$R=mysql_query($Q)or die(mysql_error());
if(mysql_affected_rows()!=-1)die("Opération réussie");
?>