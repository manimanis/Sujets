<meta charset="utf-8">
<?php
mysql_connect("localhost","root")or die (mysql_error());
mysql_select_db("bdbacpratique")or die(mysql_error());
$nom=$_POST["T1"];
$pre=$_POST["T2"];
$tel=$_POST["T3"];
$adr=$_POST["S1"];
$mdp=$_POST["T4"];
$cmp=$_POST["T5"];
$Q="select *
    from client
    where tel='$tel'";
$R=mysql_query($Q)or die(mysql_error());
if(mysql_num_rows($R)==0){
    $Q="insert into client values('$tel','$nom','$pre','$adr','$mdp')";
    $R=mysql_query($Q)or die(mysql_error());
    if(mysql_affected_rows()!=-1)die("inscription effectuée avec succès");
}
else{
    $Q="select nom,prenom from client where tel='$tel'";
    $R=mysql_query($Q)or die(mysql_error());
    $T=mysql_fetch_array($R);
    if(($T[0]!=$nom)||($T[1]!=$pre))die("erreur : tél, nom ou prénom erroné");
}
$Q="select *
    from client
    where nom='$nom' and prenom='$pre' and tel='$tel'";
$R=mysql_query($Q)or die(mysql_error());
if(mysql_num_rows($R)!=0)die("client déjà inscrit !");
?>