create table Pizza (IdPizza varchar(3) primarykey,
                    NomPizza varchar(30) ,
                     Details varchar(200) ,
                      Prix decimal(6,3));

create or replace table Client (Tel varchar(8) primary key , Nom varchar(25), Prenom varchar(25), Adresse varchar(100) ,
 MotPass varchar(6));
 create  table Commande (IdPizza varchar(3)  , Tel varchar(8) , DateCmd datetime , QteCmd int,
 primary key(IdPizza,Tel,DateCmd)
 );
 
insert into  Pizza values ("Fmr" ,"Fruits de mer"," Tomate, Mozzarella, Fruits de mer" ,18.500);
insert into  Pizza values("Mgh","Margherita"," Tomate , Mozzarella, Basilic" ,8.000);
insert into  Pizza values("Nap","Napolitaine ","Tomate, Mozzarella, Thon, Anchois", 12.000);
insert into  Pizza values("Nep","Neptune ","Tomate, Mozzarella, Thon", 10.500);
insert into  Pizza values("Roy","Royale","Tomate, Mozzarella, Jambon, Champignon", 14.500);