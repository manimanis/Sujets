function alpha(nom) {

	for (i = 0; i < nom.length; i++) {
		if ((nom[i].toUpperCase() < 'A') || (nom[i].toUpperCase() > 'Z'))
			return false;
	}
	return (nom.length >= 3);
}

function verif1() {

	var nom = document.f.nom.value;
	var prenom = document.f.prenom.value;
	var tel = document.f.tel.value;
	var adresse = document.f.adresse.value;
	var password = document.f.password.value;
	var confpassword = document.f.confpassword.value;

	if (alpha(nom) == false) {
		alert("Nom Invalide:seule les caractères alphabétiques sont accepté");
		return false;
	}
	if (alpha(prenom) == false) {
		alert("PreNom Invalide:seule les caractères alphabétiques sont accepté");
		return false;
	}
	if (isNaN(tel) || Number(tel[0]) <= 1 || (tel.length != 8)) {
		alert("Tel Invalide");
		return false;
	}
	if (adresse.length < 10) {
		alert("Adresse Invalide");
		return false;
	}
	if ((password.length != 6) || (password.indexOf(" ") >= 0)) {
		alert("Mot de passe Invalide");
		return false;
	}
	if ((password != confpassword)) {
		alert("Confirmation Mot de passe Invalide");
		return false;
	}
}
function verif2() {

	var pizza = document.f.pizza.selectedIndex;
	var tel = document.f.tel.value;
	var password = document.f.password.value;
	var quantite = Number(document.f.quantite.value);

	if (pizza == 0) {
		alert("Pizza Invalide");
		return false;
	}
	if ((quantite < 1) || (quantite > 5)) {
		alert("Quantité Invalide");
		return false;
	}
	if (isNaN(tel) || Number(tel[0]) <= 1 || (tel.length != 8)) {
		alert("Tel Invalide");
		return false;
	}

	if ((password.length != 6) || (password.indexOf(" ") >= 0)) {
		alert("Mot de passe Invalide");
		return false;
	}
}