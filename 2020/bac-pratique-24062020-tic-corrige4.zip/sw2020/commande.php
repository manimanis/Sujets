
<meta charset="utf-8">
<?php
$pizza =$_POST["pizza"];
$tel = $_POST["tel"];
$password =$_POST["password"];
$quantite = $_POST["quantite"];
$server=mysql_connect("localhost","root","");
$db=mysql_select_db("bd2020");
$req1=mysql_query("select * from client where tel='$tel' and MotPass='$password'");
if(mysql_num_rows($req1)){ 
    $insert1=mysql_query("insert into commande values('$pizza','$tel',now(),'$quantite')");
   if($insert1){
       echo("Opération réussie");
   } else
   {
        echo("Opération echoué");
   }
}
    else{
        echo("N° Tél ou mot de passe erroné !");
    }
        