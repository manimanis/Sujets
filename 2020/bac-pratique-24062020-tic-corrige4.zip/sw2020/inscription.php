
<meta charset="utf-8">
<?php
$nom =$_POST["nom"];
$prenom = $_POST["prenom"];
$tel = $_POST["tel"];
$adresse = $_POST["adresse"];
$password =$_POST["password"];
$confpassword = $_POST["confpassword"];
$server=mysql_connect("localhost","root","");
$db=mysql_select_db("bd2020");
$req1=mysql_query("select * from client where tel='$tel' ");
if(mysql_num_rows($req1)){
    $res1=mysql_fetch_array($req1);
    if (($res1[1]==$nom)&&($res1[2]==$prenom)) {
       echo("Client déjà inscrit !");
    }else
    {
        echo("Erreur : Tél, Nom ou Prénom erroné !");
    }
}else
{
   $insert1=mysql_query("insert into client values('$tel','$nom','$prenom','$adresse','$password')");
   if($insert1){
       echo("Inscription effectuée avec succès");
   } else
   {
        echo("Inscription echoué");
   }
}