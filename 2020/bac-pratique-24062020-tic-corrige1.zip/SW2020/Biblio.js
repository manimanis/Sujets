// JavaScript Document
function verif1()
{
if((isNaN(document.f1.t1.value)==false) || (document.f1.t1.value.length<3))
{
	alert ("nom invalide"); return false;}
	
if((isNaN(document.f1.t2.value)==false) || (document.f1.t2.value.length<3))
{
	alert ("pr�nom invalide"); return false;}
	
if((isNaN(document.f1.t3.value)==true) || (document.f1.t3.value.length!=8) || (document.f1.t3.value.charAt(0)<=1))
{
	alert ("Num Tel invalide"); return false;}
if(document.f1.tx.value.length<10)
{
	alert ("verifiez ton Adresse"); return false;}
if((document.f1.t4.value.indexOf(" ")!=-1)||(document.f1.t4.value.length!=6))
	{
		alert("mot de passe incorrecte"); return false;}
mp=document.f1.t4.value;
cmp=document.f1.t5.value;
if(mp != cmp)
{
	alert("confirmer votr mot de passe"); return false;}
}

function verif2()
{
if(document.f2.list.selectedIndex==0)
{
	alert("s�lectioner une Pizza"); return false;}
if((isNaN(document.f2.td1.value)==true)||(document.f2.td1.value>5)||(document.f2.td1.value<1))
 {
	 alert("verifer la quantit�"); return false;}
 
if((isNaN(document.f2.td2.value)==true) || (document.f2.td2.value.length!=8) || (document.f2.td2.value.charAt(0)<=1))
{
	alert ("Num Tel invalide"); return false;}
if((document.f2.td3.value.indexOf(" ")!=-1)||(document.f2.td3.value.length!=6))
	{
		alert("mot de passe incorrecte"); return false;}
	}