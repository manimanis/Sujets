<?
$tp=$_POST['list'];
$qet=$_POST['td1'];
$t=$_POST['td2'];
$mp=$_POST['td3'];
//echo($tp."<br>");
mysql_connect("localhost","root","") or die ("connection impossible<br>");
mysql_select_db("BD2020") or die ("selection de la base impossible<br>");
$rq1="select Tel, MotPass From Client where Tel='$t' AND MotPass='$mp' ;";
$res1=mysql_query($rq1);
$d= date("Y-m-d H:m:s");
if( mysql_num_rows($res1)!=0)
{//echo(mysql_num_rows($res1));
$req2="SELECT IdPizza from Pizza where NomPizza='$tp';";
 $res2=mysql_query($req2);
 $i=mysql_fetch_array($res2);
 $id=$i["IdPizza"];
 //echo("<br>".$id);
 $req3="INSERT INTO Commande values('$id','$t','$d','$qet');";
 $res3=mysql_query($req3);
  if(mysql_affected_rows()>0)
 {echo ("Op�ration r�ussie! ");}
 else
 {echo ("prbl�me d'ajout d'une commande!!!");}
}
else
{echo("N� T�l ou mot de passe erron�!!");}
mysql_close();
?>