<?
mysql_connect("localhost","root","") or die ("erreur de connexion au serveur");
mysql_select_db("bd")or die ("erreur de selection de base de donn�es");
$a=$_POST['t1'];
$b=$_POST['t2'];
$req="select Num_Compte,MotPasse from Comte where (Num_Compte='$a')and(MotPasse='$b')";
$res=mysql_query($req);
$nb=mysql_num_rows($res);
if($nb==0)
{echo("Contacter votre banque pour v�rifier les param�tres de votre identification");}
else
{
$req1="select count(Num_Compte),Num_Compte,DateTrans,LibelleTrans,MontTrans  from Transaction where Num_Compte='$a' GROUP BY(Num_Compte)";
$res1=mysql_query($req1);
$ligne=mysql_fetch_row($res1);

echo $ligne[0].'  ';
echo $ligne[2].'  ';
echo $ligne[3].'  ';
echo $ligne[4].'  ';
}
mysql_close();
?>
