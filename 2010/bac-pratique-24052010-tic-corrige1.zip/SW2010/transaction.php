<?
mysql_connect("localhost","root","") or die ("erreur de connexion au serveur");
mysql_select_db("bd")or die ("erreur de selection de base de donn�es");
$a=$_POST['t1'];
$b=$_POST['t2'];
$c=$_POST['t3'];
$d=$_POST['t4'];
$req="insert into Transaction values ('','$b','$a','$c','$d')";
$res=mysql_query($req);
if(mysql_affected_rows()==-1)
{echo("Enregistrement echou�");}
else
{echo("Enregistrement termin�");}

$req1="select Num_Compte,Solde from Comte where (Num_Compte='$b')";
$res1=mysql_query($req1);
$nb=mysql_num_rows($res1);
if($nb==0)
{echo("compte invalide");}
else
{
    $req2="update Comte set Solde='$d'where (Num_Compte='$b')and(Solde >='$d') ";
    $res2=mysql_query($req2);
    if(mysql_affected_rows()==-1)
    {echo("Transaction echou�e");}
    else
    {echo("Modification termin�");}
}
mysql_close();
?>
